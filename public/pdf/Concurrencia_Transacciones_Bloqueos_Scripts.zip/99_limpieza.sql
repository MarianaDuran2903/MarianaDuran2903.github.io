-- =====================================================================
-- 99_limpieza.sql — cada pareja, al terminar
-- =====================================================================
SET SERVEROUTPUT ON

-- Por si quedó alguna transacción abierta
ROLLBACK;

BEGIN
  FOR t IN (SELECT table_name FROM user_tables
             WHERE table_name IN ('MOVIMIENTO','CUENTA','ASIENTO',
                                  'SILLA','TRABAJO','BASURA_TEMPORAL')) LOOP
    EXECUTE IMMEDIATE 'DROP TABLE '||t.table_name||' CASCADE CONSTRAINTS PURGE';
    DBMS_OUTPUT.PUT_LINE('Eliminada: '||t.table_name);
  END LOOP;
END;
/

PURGE RECYCLEBIN;
SELECT table_name FROM user_tables ORDER BY 1;

-- ---------------------------------------------------------------------
-- Y el docente, como ADMIN, si quiere borrar los usuarios:
--   BEGIN
--     FOR u IN (SELECT username FROM dba_users WHERE username LIKE 'P__') LOOP
--       EXECUTE IMMEDIATE 'DROP USER '||u.username||' CASCADE';
--     END LOOP;
--   END;
--   /
-- ---------------------------------------------------------------------
