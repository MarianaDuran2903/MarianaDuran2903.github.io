-- =====================================================================
-- Bases de Datos 2 · Taller integrador — MercaAndes
-- 02_indices.sql   —ndices y optimización de consultas
--
-- IMPORTANTE: de aquí en adelante trabajen en UNA SOLA CONEXI—N.
-- La pareja comparte el mismo esquema, y dos personas creando índices o
-- insertando en la misma tabla al mismo tiempo se bloquean entre sí.
-- Uno maneja el teclado, los dos discuten y anotan.
--
-- Ejecute bloque por bloque con Ctrl+Enter.
-- =====================================================================

SET TIMING ON
SET LINESIZE 200
SET PAGESIZE 1000

-- ---------------------------------------------------------------------
-- C—MO VAMOS A MEDIR
--
-- En SQL Developer tiene tres herramientas. —selas todas:
--
--   F10  Explain Plan   -> el plan que el optimizador PIENSA usar.
--                          No ejecuta la consulta. Es una estimación.
--   F6   Autotrace      -> ejecuta la consulta y muestra el plan REAL
--                          más las estadísticas de sesión.
--   F5   Run Script     -> para los bloques con SET TIMING.
--
-- Las dos cifras que importan:
--   COST            estimación del optimizador (sirve para comparar)
--   consistent gets bloques leídos de verdad (esta es la que no miente)
--
-- También puede pedir el plan por texto, así:
-- ---------------------------------------------------------------------

EXPLAIN PLAN FOR
SELECT COUNT(*) FROM pedido WHERE estado = 'ENTREGADO';

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST +ROWS'));


-- #####################################################################
-- EJERCICIO 2.1 — La consulta del informe diario
--
-- Operaciones necesita, todas las mañanas, el total facturado y el
-- número de pedidos entregados del mes anterior.
-- #####################################################################

-- PASO 1  Ejecute la consulta y mida
SELECT COUNT(*)        AS pedidos,
       SUM(total)      AS facturado,
       ROUND(AVG(total)) AS ticket_promedio
  FROM pedido
 WHERE fecha_pedido >= DATE '2026-03-01'
   AND fecha_pedido <  DATE '2026-04-01'
   AND estado        = 'ENTREGADO';

-- PASO 2  Vea el plan
EXPLAIN PLAN FOR
SELECT COUNT(*), SUM(total)
  FROM pedido
 WHERE fecha_pedido >= DATE '2026-03-01'
   AND fecha_pedido <  DATE '2026-04-01'
   AND estado        = 'ENTREGADO';

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST +ROWS'));
--
--  ANOTE:  operación = _______Table Access Full_______   COST = ___309___   filas = ___5289___
--
--  PREGUNTA 2.1 — La tabla tiene 200.000 filas y la consulta devuelve
--  unos pocos miles. ¿Por qué el optimizador está leyendo la tabla
--  completa? ¿Es un error del optimizador?

-- RTA/: no es un error del optimizador, es que no hay ningún índice que pueda usar,
-- es por eso que la unica opcion que le queda es leer la tabla completa con TABLE ACCESS FULL.


-- PASO 3  Cree el índice
CREATE INDEX ix_pedido_fecha_estado ON pedido (fecha_pedido, estado);

EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'PEDIDO', cascade => TRUE);


-- PASO 4  Repita la medición
EXPLAIN PLAN FOR
SELECT COUNT(*), SUM(total)
  FROM pedido
 WHERE fecha_pedido >= DATE '2026-03-01'
   AND fecha_pedido <  DATE '2026-04-01'
   AND estado        = 'ENTREGADO';

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST +ROWS'));
--
--  ANOTE:  operación = _______TABLE ACCESS FULL_______   COST = ___309___    filas = ___4715___
--
--  PREGUNTA 2.2 — ¿Cuánto bajó el COST? Ejecute también con F6
--  (Autotrace) antes y después y compare los "consistent gets".
-- RTA/: El costo no bajo, porque el hecho de que el indice exista no significa que lo vaya a usar
--       si el optimizador no lo considera util o eficiente en este caso, aunque el numero de filas si bajo.

-- PASO 5  El orden de las columnas S— importa
CREATE INDEX ix_pedido_estado_fecha ON pedido (estado, fecha_pedido);

EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'PEDIDO', cascade => TRUE);

-- Fuerce cada índice y compare
SELECT /*+ INDEX(p ix_pedido_fecha_estado) */ COUNT(*)
  FROM pedido p
 WHERE fecha_pedido >= DATE '2026-03-01'
   AND fecha_pedido <  DATE '2026-04-01'
   AND estado        = 'ENTREGADO';

SELECT /*+ INDEX(p ix_pedido_estado_fecha) */ COUNT(*)
  FROM pedido p
 WHERE fecha_pedido >= DATE '2026-03-01'
   AND fecha_pedido <  DATE '2026-04-01'
   AND estado        = 'ENTREGADO';
--
--  PREGUNTA 2.3 — ¿Cuál de los dos índices elige el optimizador cuando
--  no se le fuerza nada? Compare el COST de los dos SELECT anteriores.
--  Formule la regla general sobre el orden de columnas en un índice
--  compuesto, distinguiendo el predicado de IGUALDAD del de RANGO.

-- -- RTA 2.3/: El optimizador elige IX_PEDIDO_ESTADO_FECHA, que tiene el COST mas bajo de los dos.
-- En un indice compuesto van primero las columnas con predicado de
-- IGUALDAD y de ultima la del predicado de RANGO. Aqui estado='ENTREGADO'
-- es igualdad y fecha_pedido es rango, asi que (estado, fecha_pedido)
-- permite entrar por un punto exacto y recorrer un tramo continuo del
-- indice. Con (fecha_pedido, estado) toca recorrer todas las entradas de
-- marzo y descartar una por una las que no son ENTREGADO.
--
--  PREGUNTA 2.4 — Suponga ahora que existe además un informe que filtra
--  SOLO por rango de fechas, sin estado. ¿Cuál de los dos índices le
--  sirve a ese informe y cuál no? ¿Cambia eso su recomendación?
--  Responda cuál de los dos conservaría en producción y por qué.

-- RTA 2.4/: A ese informe le sirve IX_PEDIDO_FECHA_ESTADO, porque fecha_pedido es la primera columna del indice.
-- IX_PEDIDO_ESTADO_FECHA no le sirve: sin un valor de estado no hay por donde entrar al indice.
-- Si, cambia la recomendacion. En produccion conservaria IX_PEDIDO_FECHA_ESTADO: es un poco peor para la consulta del 2.1, pero
-- sirve a las dos, y un solo indice cuesta la mitad en escrituras que dos.
-- No se elige el indice optimo para una consulta, sino el mejor conjunto para toda la carga.

-- Para el resto del taller trabajamos con IX_PEDIDO_FECHA_ESTADO,
-- para no multiplicar índices. Su recomendación va en la entrega.
DROP INDEX ix_pedido_estado_fecha;


-- #####################################################################
-- EJERCICIO 2.2 — El índice que existe y no se usa
--
-- Soporte busca productos por nombre y se queja de que va lento.
-- #####################################################################

-- PASO 1  Sin índice
EXPLAIN PLAN FOR
SELECT id_producto, sku, nombre, precio
  FROM producto WHERE UPPER(nombre) = 'TECLADO MEC—NICO MODELO 4001';

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST'));

-- PASO 2  Creo el índice "obvio"
CREATE INDEX ix_producto_nombre ON producto (nombre);
EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'PRODUCTO', cascade => TRUE);

EXPLAIN PLAN FOR
SELECT id_producto, sku, nombre, precio
  FROM producto WHERE UPPER(nombre) = 'TECLADO MEC—NICO MODELO 4001';

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST'));
--
--  PREGUNTA 2.5 — El índice existe y sigue haciendo FULL SCAN.
--  ¿Por qué? ¿Qué le hizo la consulta a la columna indexada?

--  RTA/: Sigue en FULL SCAN porque se le aplico la funcion
-- UPPER a la columna indexada. El indice guarda el nombre tal como esta y la consulta busca la version en
-- mayusculas, que no esta guardada en ninguna parte.asi que lee cada fila, le aplica UPPER y compara.

-- PASO 3  El índice que sí sirve
CREATE INDEX ix_producto_nombre_upper ON producto (UPPER(nombre));
EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'PRODUCTO', cascade => TRUE);

EXPLAIN PLAN FOR
SELECT id_producto, sku, nombre, precio
  FROM producto WHERE UPPER(nombre) = 'TECLADO MEC—NICO MODELO 4001';

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST'));

-- PASO 4  El mismo error, con fechas.  Este es el más común de todos.
EXPLAIN PLAN FOR
SELECT COUNT(*) FROM pedido WHERE TRUNC(fecha_pedido) = DATE '2026-03-15';
SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST'));

EXPLAIN PLAN FOR
SELECT COUNT(*) FROM pedido
 WHERE fecha_pedido >= DATE '2026-03-15'
   AND fecha_pedido <  DATE '2026-03-16';
SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST'));
--
--  PREGUNTA 2.6 — Las dos consultas devuelven exactamente lo mismo.
--  Compare los planes. Escriba la regla, en una frase, que todo
--  desarrollador debería tener presente al filtrar por fecha.

-- RTA 2.6/: La primera consulta hace FULL SCAN y la segunda usa el indice,
-- aunque devuelven lo mismo(274 pedidos). El TRUNC() le cambia el valor a la columna, y
-- el indice guarda la fecha original, no la truncada: Oracle no puede
-- buscar algo que el indice no tiene, asi que le toca leer toda la tabla.
-- Regla: nunca aplicarle una funcion a la columna de fecha en el WHERE;
-- convertir el filtro en un rango  fecha >= inicio AND fecha < fin.


-- #####################################################################
-- EJERCICIO 2.3 — Cuándo NO conviene un índice
-- #####################################################################

-- PASO 1  Un filtro que devuelve el 62% de la tabla
CREATE INDEX ix_pedido_estado ON pedido (estado);
EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'PEDIDO', cascade => TRUE);

EXPLAIN PLAN FOR
SELECT COUNT(*), SUM(total) FROM pedido WHERE estado = 'ENTREGADO';
SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST +ROWS'));

-- PASO 2  El mismo índice, con un valor poco frecuente
EXPLAIN PLAN FOR
SELECT COUNT(*), SUM(total) FROM pedido WHERE estado = 'ANULADO';
SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST +ROWS'));
--
--  PREGUNTA 2.7 — El mismo índice, la misma consulta, distinto valor:
--  en un caso se usa y en el otro no. ¿Cómo lo sabe el optimizador?
--  ¿Qué información necesita para tomar esa decisión?

-- RTA 2.7/: Lo sabe por las estadisticas. Oracle estima cuantas filas va a devolver el filtro antes de
-- ejecutar: ENTREGADO es el 62% de la tabla y ANULADO el 2%. Cuando el filtro trae casi toda la tabla, saltar fila por
-- fila desde el indice sale mas caro que leerla de corrido; con el 2% el indice gana.
-- La info que necesita: num_distinct, density y sobre todo el HISTOGRAMA, porque sin el asumiria que cada uno
-- de los 5 estados es el 20% y trataria igual a los dos casos.
--
--  PREGUNTA 2.8 — Consulte la selectividad y el clustering factor:
--
--
--
SELECT column_name, num_distinct, num_nulls, density
  FROM user_tab_col_statistics
 WHERE table_name = 'PEDIDO' AND column_name IN ('ESTADO','FECHA_PEDIDO','ID_CLIENTE');

SELECT index_name, num_rows, distinct_keys, clustering_factor, blevel, leaf_blocks
  FROM user_indexes WHERE table_name = 'PEDIDO';
--
--  ¿Qué le dice el CLUSTERING FACTOR de IX_PEDIDO_FECHA_ESTADO comparado
--  con el de IX_PEDIDO_ESTADO? ¿Por qué son tan distintos?

-- RTA 2.8/: El clustering factor dice cuantos saltos a la tabla toca dar para
-- leer las filas por ese indice. Entre mas alto, mas caro es usarlo.
-- IX_PEDIDO_FECHA_ESTADO = 200.001 con NUM_ROWS = 200.011: un salto por cada
-- fila, o sea el peor caso posible. IX_PEDIDO_ESTADO = 5.345, mucho mejor.
-- El ideal seria el numero de bloques de la tabla, que son ~1.071, y eso es
-- justo lo que da PK_PEDIDO.
-- Son distintos por como quedaron guardadas las filas. Los pedidos se
-- insertaron en orden de id_pedido, y por eso la PK tiene el mejor valor. La
-- fecha en cambio se calculo con MOD(n*7,730), que salta en cada fila, asi que
-- dos pedidos con fechas seguidas quedaron en extremos opuestos de la tabla.
-- Y el estado solo tiene 5 valores que se repiten todo el tiempo, asi que las
-- filas de un mismo estado caen muchas por bloque y el numero baja.

-- #####################################################################
-- EJERCICIO 2.4 — El índice que evita tocar la tabla
-- #####################################################################

-- PASO 1  Consulta de clientes activos del trimestre
EXPLAIN PLAN FOR
SELECT id_cliente, COUNT(*) AS pedidos
  FROM pedido
 WHERE fecha_pedido >= DATE '2026-01-01'
   AND fecha_pedido <  DATE '2026-04-01'
 GROUP BY id_cliente;

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST'));
--> Fíjese: hay INDEX RANGE SCAN y ADEM—S TABLE ACCESS BY INDEX ROWID.

-- PASO 2  Agrego la columna que falta al índice
CREATE INDEX ix_pedido_fecha_cliente ON pedido (fecha_pedido, id_cliente);
EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'PEDIDO', cascade => TRUE);

EXPLAIN PLAN FOR
SELECT id_cliente, COUNT(*) AS pedidos
  FROM pedido
 WHERE fecha_pedido >= DATE '2026-01-01'
   AND fecha_pedido <  DATE '2026-04-01'
 GROUP BY id_cliente;

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST'));
--
--  PREGUNTA 2.9 — Desapareció el TABLE ACCESS. ¿Cómo se llama esta
--  técnica y por qué es tan efectiva? ¿Cuál es su límite: hasta dónde
--  tiene sentido seguir agregando columnas al índice?

-- RTA 2.9/: Se llama indice de cobertura. Desaparecio el TABLE ACCESS
-- porque el indice ya trae fecha_pedido e id_cliente, que es todo lo que la
-- consulta necesita: no hay que ir a la tabla a buscar nada mas. Se ahorra
-- un salto a la tabla por cada fila encontrada.
-- El limite: cada columna extra engorda el indice y encarece cada INSERT,
-- UPDATE y DELETE. Vale la pena con una o dos columnas para una consulta
-- frecuente; meter media tabla ya es hacer una copia que toca mantener.


-- #####################################################################
-- EJERCICIO 2.5 — Lo que cuesta un índice
--
-- Hasta aquí solo hemos visto el beneficio. Ahora el precio.
-- #####################################################################

-- PASO 1  Cuántos índices tiene PEDIDO en este momento
SELECT index_name, leaf_blocks,
       ROUND(leaf_blocks * 8192 / 1024 / 1024, 2) AS mb_aprox
  FROM user_indexes WHERE table_name = 'PEDIDO';

-- PASO 2  Inserte 50.000 pedidos CON todos los índices y mida el tiempo
--   (ejecute este bloque con F5 para ver el TIMING)
SET TIMING ON
INSERT INTO pedido (id_pedido, id_cliente, fecha_pedido, estado, canal, total)
SELECT 1000000 + LEVEL, MOD(LEVEL,20000)+1,
       DATE '2026-06-01' + MOD(LEVEL,30), 'CREADO', 'WEB', 100000
  FROM dual CONNECT BY LEVEL <= 50000;
COMMIT;
--> Anote el tiempo: ___2.189 s___

-- PASO 3  Ahora sin índices secundarios
DROP INDEX ix_pedido_fecha_estado;
DROP INDEX ix_pedido_estado;
DROP INDEX ix_pedido_fecha_cliente;

INSERT INTO pedido (id_pedido, id_cliente, fecha_pedido, estado, canal, total)
SELECT 2000000 + LEVEL, MOD(LEVEL,20000)+1,
       DATE '2026-06-01' + MOD(LEVEL,30), 'CREADO', 'WEB', 100000
  FROM dual CONNECT BY LEVEL <= 50000;
COMMIT;
--> Anote el tiempo: ___0.373___

-- PASO 4  Deje el esquema como debe quedar
DELETE FROM pedido WHERE id_pedido >= 1000000;
COMMIT;

CREATE INDEX ix_pedido_fecha_estado  ON pedido (fecha_pedido, estado);
CREATE INDEX ix_pedido_fecha_cliente ON pedido (fecha_pedido, id_cliente);
EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'PEDIDO', cascade => TRUE);
--
--  PREGUNTA 2.10 — ¿Cuál fue la diferencia de tiempo? Extrapole:
--  MercaAndes recibe 8.000 pedidos por hora en temporada. ¿Qué costo
--  operativo tiene cada índice que se agrega "por si acaso"?
--
-- RTA 2.10/: Con los 3 indices el INSERT de 50.000 filas tardo 2,189 s y sin
-- ellos 0,373 s: casi 6 veces mas lento. El 83% del tiempo se fue en mantener
-- los indices, no en escribir los datos. Son 1,816 s de sobrecosto por 50.000
-- filas, o sea unos 0,036 ms por fila con los tres indices.
-- Extrapolando a 8.000 pedidos por hora, cada indice cuesta ~0,10 s por hora,
-- ~2,3 s al dia y ~14 min de CPU al año, y eso solo en PEDIDO: si el indice
-- fuera sobre PEDIDO_DETALLE seria el doble o el triple, porque cada pedido
-- tiene de 1 a 3 lineas.
-- El costo real no es solo tiempo: cada indice ocupa disco, alarga los
-- backups y consume memoria. Un indice puesto "por si acaso" que ninguna
-- consulta usa es costo puro sin beneficio, y se paga en cada escritura,
-- para siempre.
--
--  PREGUNTA 2.11 — Proponga la lista DEFINITIVA de índices para este
--  esquema. Para cada uno escriba: qué consulta lo justifica, y por qué
--  no se puede resolver con otro índice ya existente.

-- RTA/:
--
-- 1. PEDIDO (fecha_pedido, estado). Lo usan los informes mensuales y el
--    tablero. Ningun indice tiene la fecha, la PK es por id_pedido. Se
--    prefiere este orden porque tambien sirve a los informes que filtran
--    solo por fecha.
--
-- 2. PAGO (id_pedido). La FK del ejercicio 1.5. La PK es por id_pago, y
--    sin este indice borrar un pedido bloquea toda la tabla PAGO.
--
-- 3. PEDIDO_DETALLE (id_producto). Las ventas por producto y la FK hacia
--    PRODUCTO. La PK empieza por id_pedido, no sirve para buscar producto.
--
-- 4. PEDIDO (id_cliente). El historial por cliente, el informe de PREMIUM
--    inactivos y la FK hacia CLIENTE. La PK es por id_pedido.
--
-- 5. PRODUCTO (UPPER(nombre)). La busqueda de soporte del 2.2. El indice
--    normal sobre nombre no se usa cuando el predicado aplica UPPER.
--
-- SE DESCARTAN:
-- - PEDIDO (estado): ENTREGADO es el 62% de la tabla, el optimizador no lo
--   usa (ejercicio 2.3).
-- - PEDIDO (fecha_pedido, id_cliente): se solapa con el 1 y seria un tercer
--   indice sobre la tabla que mas escribe (ejercicio 2.5).
-- - FK sobre datos maestros (producto.id_categoria, categoria.id_padre,
--   inventario.id_bodega): de esas tablas casi no se borran filas.
