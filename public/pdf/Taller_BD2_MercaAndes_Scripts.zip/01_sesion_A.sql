-- =====================================================================
-- Bases de Datos 2 · Taller integrador — MercaAndes
-- 01_sesion_A.sql        >>>  CONEXI—N A  <<<
--
-- NO ejecute este archivo de corrido. Cada bloque dice PASO n:
-- ejecútelo con Ctrl+Enter cuando le toque, alternando con la conexión B.
--
-- ANTES DE EMPEZAR, verifique:
--   1. Autocommit APAGADO
--      Herramientas > Preferencias > Base de datos > Avanzado > Autoconfirmar
--      (debe estar DESMARCADO)
--   2. Dos CONEXIONES distintas, no dos hojas sobre la misma conexión.
-- =====================================================================

SELECT 'CONEXI—N A' AS ventana, SYS_CONTEXT('USERENV','SID') AS sid FROM dual;


-- #####################################################################
-- EJERCICIO 1.1 — La venta que se pierde (actualización perdida)
--
-- Escenario: dos compradores toman la última unidad del producto 100
-- en la bodega 1 al mismo tiempo. La aplicación lee el stock, resta en
-- memoria y escribe el resultado. Es lo que hace la mayoría del código
-- que ustedes van a encontrar en producción.
-- #####################################################################

-- PASO 1  (A)  Estado inicial
SELECT id_producto, id_bodega, disponible, reservado, version
  FROM inventario WHERE id_producto = 100 AND id_bodega = 1;
--> Anote el valor de DISPONIBLE.
-- En este paso DISPONIBLE = 10

-- PASO 2  (A)  "La aplicación" leyó 10 y calculó 10 - 3 = 7
UPDATE inventario SET disponible = 7
 WHERE id_producto = 100 AND id_bodega = 1;
--  NO confirme todavía.

-- ... vaya a la conexión B, PASO 3 ... En este paso, consulta se quedo cargando

-- PASO 5  (A)  Confirmo mi venta de 3 unidades
COMMIT;

-- ... conexión B, PASO 6 ...

-- PASO 8  (A)  ¿Cuánto stock quedó?
SELECT id_producto, disponible FROM inventario
 WHERE id_producto = 100 AND id_bodega = 1;

 -- Quedo el 6, ya que segun el orden del commit hecho por A y B, B hizo commit despues, no estamos haciendo operaciones sino cambiando el resultado con un set
--
--  PREGUNTA 1.1 — Se vendieron 3 unidades (A) más 4 (B) = 7 de 10.
--  Deberían quedar 3. ¿Cuántas quedan? ¿Quién "ganó"? ¿Hubo algún error,
--  alguna advertencia, algún registro de que algo salió mal?

-- RTA:/ Quedaron 6, en esta sentencia, ganó B, ya que segun el orden del commit hecho por A y B, B hizo commit despues;
-- no estamos haciendo operaciones sino cambiando el resultado con un set por lo que no se puede decir que se vendieron
-- unidades, sino que se cambio el valor por orden. En conclusion B ganó.

--  PREGUNTA 1.2 — El bloqueo de fila S— funcionó: B esperó a que A
--  confirmara. Explique entonces por qué se perdió una venta de todos
--  modos.

-- RTA:/ La venta se perdio por que la sentencia no calculo el valor restandole lo que se vendio, si no simplemente se actualizo el dato con un set por un
-- dato en especifico. B hizo lo mismo anulando la venta anterior asumiendo que seguian habiendo 10 disponibles, cuando realmente se redujo.

UPDATE inventario SET disponible = disponible-3
WHERE id_producto = 100 AND id_bodega = 1;

-- #####################################################################
-- EJERCICIO 1.2 — Defensa pesimista: SELECT ... FOR UPDATE
-- #####################################################################

-- PASO 1  (A)  Dejo el producto 100 en un valor conocido
UPDATE inventario SET disponible = 10, version = 0
 WHERE id_producto = 100 AND id_bodega = 1;
COMMIT;

-- PASO 2  (A)  Leo Y bloqueo en la misma operación
SELECT id_producto, disponible
  FROM inventario
 WHERE id_producto = 100 AND id_bodega = 1
   FOR UPDATE;

-- ... conexión B, PASO 3 ...

-- PASO 5  (A)  Descuento mis 3 unidades y libero
UPDATE inventario SET disponible = disponible - 3
 WHERE id_producto = 100 AND id_bodega = 1;
COMMIT;

-- ... conexión B, PASO 6 ...

-- PASO 8  (A)  Resultado
SELECT id_producto, disponible FROM inventario
 WHERE id_producto = 100 AND id_bodega = 1;
--
--  PREGUNTA 1.3 — Ahora sí quedan 3. ¿Qué dos cosas cambiaron respecto
--  al ejercicio anterior? (pista: una es el FOR UPDATE, la otra está
--  dentro del UPDATE mismo)

--RTA:/ - El FOR UPDATE bloquea la fila desde que se lee, no desde que se escribe. B no puede leer con intencion de escribir hasta que A termine.
--      - En el UPDATE el valor nuevo lo calcula la base de datos sobre el dato actual, no sobre un dato viejo.
--
--  PREGUNTA 1.4 — ¿Cuál fue el precio que se pagó por esta seguridad?
-- RTA:/Se pierde la concurrencia: - las operaciones sobre esa fila dejan de ejecutarse en paralelo.
--                                 - el bloqueo se mantiene hasta el COMMIT y no hasta el UPDATE, cada sesion que espera consume una conexion sin trabajar.

-- #####################################################################
-- EJERCICIO 1.3 — Defensa optimista: columna de versión
--
-- Nadie bloquea nada. El choque se detecta al escribir.
-- #####################################################################

-- PASO 1  (A)  Reinicio
UPDATE inventario SET disponible = 10, version = 0
 WHERE id_producto = 100 AND id_bodega = 1;
COMMIT;

-- PASO 2  (A)  Leo el stock y la versión.  NO bloqueo nada.
SELECT id_producto, disponible, version
  FROM inventario WHERE id_producto = 100 AND id_bodega = 1;
--> Anote la versión que ve.
-- RTA:/ Para el producto 100, la version vista es 0.

-- ... conexión B, PASO 3: lee lo mismo y escribe PRIMERO ...

-- PASO 5  (A)  Intento escribir con la versión que leí
UPDATE inventario
   SET disponible = disponible - 3,
       version    = version + 1
 WHERE id_producto = 100 AND id_bodega = 1
   AND version     = 0;              -- <-- la versión que leí en el PASO 2
COMMIT;
--
--  Mire el mensaje: ¿cuántas filas actualizó?
-- RTA:/ El mensaje dice: 0 filas actualizadas

-- PASO 6  (A)
SELECT id_producto, disponible, version FROM inventario
 WHERE id_producto = 100 AND id_bodega = 1;
--
--  PREGUNTA 1.5 — Su UPDATE afectó 0 filas. ¿Qué debe hacer la
--  aplicación en ese momento, y qué NO debe hacer nunca?
--  RTA:/  -Lo que debe hacer: verificar siempre la fila con la versión nueva, teniendo en cuenta si alcanza el stock, y en caso tal, reintentar.
--         -Lo que nunca debe hacer: ignorar el resultado y seguir como si el UPDATE hubiera funcionado. "0 filas actualizadas" no es un error.
--          Si la aplicacion no revisa cuantas filas afecto, existen fallas.

--
--  PREGUNTA 1.6 — Compare las dos defensas. ¿En qué escenario de este
--  marketplace usaría la pesimista y en cuál la optimista? Justifique
--  con el nivel de contención esperado, no con opiniones.

-- RTA;/ La decision depende de qué tan seguido dos sesiones se peleen la misma fila
-- Pesimista: En INVENTARIO, porque muchos pedidos pueden modificar las mismas filas al mismo tiempo.
-- Como los conflictos son frecuentes, es mejor bloquear y esperar que tener que reintentar constantemente.
-- Optimista: En CLIENTE o PEDIDO, porque normalmente una fila es modificada por una sola persona.
-- Como los conflictos son poco frecuentes, es mejor no bloquear y reintentar solo si ocurre un conflicto.

-- #####################################################################
-- EJERCICIO 1.4 — Repartir la cola de despacho: SKIP LOCKED
--
-- Dos operarios toman tareas de la misma cola. No pueden repetirse el
-- trabajo, y no pueden quedarse esperando el uno al otro.
-- #####################################################################

-- PASO 1  (A)  Tomo 5 tareas y las marco como mías
SELECT id_tarea, id_pedido
  FROM tarea_despacho
 WHERE estado = 'PENDIENTE'
   AND ROWNUM <= 5
   FOR UPDATE SKIP LOCKED;
--  Nota de sintaxis: aquí se usa ROWNUM y no FETCH FIRST ... ROWS ONLY.
--  Oracle implementa FETCH FIRST como una vista en línea, y combinarlo
--  con FOR UPDATE devuelve ORA-02014. Para una cola de trabajo ROWNUM es
--  además lo correcto: no importa CU—LES cinco tareas toma, importa que
--  sean cinco libres y que nadie más las tenga.

--> Anote los id_tarea que le tocaron.  NO confirme todavía.
-- RTA:/ id_tarea: 1,2,3,4,5

-- ... conexión B, PASO 2: pide 5 tareas y recibe OTRAS distintas ...

-- PASO 3  (A)  Marco las mías como procesadas y libero
UPDATE tarea_despacho
   SET estado = 'PROCESADA', tomada_por = 'OPERARIO_A', fecha_toma = SYSTIMESTAMP
 WHERE id_tarea IN (1,2,3,4,5);      -- <-- reemplace por los ids que le tocaron
COMMIT;

-- PASO 5  (A)  Verificación conjunta
SELECT tomada_por, COUNT(*) AS tareas
  FROM tarea_despacho WHERE estado = 'PROCESADA'
 GROUP BY tomada_por;
--
--  PREGUNTA 1.7 — ¿Qué habría pasado sin SKIP LOCKED? Describa los dos
--  comportamientos posibles según se use FOR UPDATE simple o NOWAIT.
-- RTA:/ sin SKIP LOCKED: - con FOR UPDATE: B al intentar trababjar en una fila ocupada, lo deja esperando a que A lo libere.
--                          Con el SKIP busca filas que no esten ocupadas para asi no tener que esperar.
--                        - FOR UPDATE NOWAIT: B falla de inmediato con error. No espera, pero tampoco puede trabajar con otras filas.
--
--
--  PREGUNTA 1.8 — ¿Por qué SKIP LOCKED es la base de las colas de
--  trabajo implementadas sobre tablas? ¿Qué componente de arquitectura
--  se ahorra uno con esto?
-- RTA:/ Es la base de las colas de trabajo porque reparte las tareas de manera automatica sin que a una persona
--       le toque la tarea de otro, osea sin repetir tareas.
--      - Se ahorra un sistema de colas externo como puede ser un Message Broker
-- #####################################################################
-- EJERCICIO 1.5 — El bloqueo que nadie espera: FK sin índice
--
-- PAGO.ID_PEDIDO es llave foránea hacia PEDIDO y NO está indexada.
-- #####################################################################

-- PASO 1  (A)  Registro un pago del pedido 900001.  NO confirmo.
INSERT INTO pago (id_pago, id_pedido, fecha_pago, valor, estado)
VALUES (9000001, 900001, SYSDATE, 50000, 'APROBADO');

-- ... conexión B, PASO 2: intenta borrar el pedido 900005, que no tiene
--     ningún pago ni ningún detalle, y se queda esperando ...

-- PASO 3  (A)  Mientras B espera, mire el bloqueo.
--   TX = bloqueo de fila.  TM = bloqueo de TABLA.
SELECT l.sid, l.type,
       DECODE(l.lmode, 0,'ninguno',1,'null',2,'RS',3,'RX',4,'S',5,'SRX',6,'X') AS tiene,
       DECODE(l.request,0,'-',1,'null',2,'RS',3,'RX',4,'S',5,'SRX',6,'X')      AS pide
  FROM v$lock l JOIN v$session s ON s.sid = l.sid
 WHERE s.username = USER AND l.type IN ('TX','TM');
--> Si no tiene permisos sobre V$, el docente lo proyecta.

-- PASO 4  (A)  Libero
COMMIT;

-- PASO 6  (A)  Creo el índice que faltaba
CREATE INDEX ix_pago_pedido ON pago (id_pedido);

-- PASO 7  (A)  Repitan los pasos 1 y 2. Ahora B NO se bloquea.
--
--  PREGUNTA 1.9 — Explique por qué Oracle toma un bloqueo de TABLA sobre
--  el hijo cuando se borra un padre y la FK no está indexada.
--
-- RTA/ Al borrar un pedido, se debe comprobar que no queden pagos apuntando a él.
-- Como PAGO.ID_PEDIDO no tiene índice, se recorre la tabla de pagos entera, bloqueando toda la tabla PAGO.
-- Por eso una sesión que borra un pedido cualquiera bloquea a otra que está trabajando en pagos que no tienen nada que ver.
-- Con el índice, la comprobación es una búsqueda puntual y basta con bloquear a nivel de fila.
--
--
--  PREGUNTA 1.10 — Revise el esquema completo de MercaAndes. ¿Qué OTRAS
--  llaves foráneas están sin índice? ¿Cuáles de ellas son realmente un
--  problema y cuáles no? Justifique.
-- RTA:/
--    FKs sin indice en el esquema:
--    categoria.id_padre
--    producto.id_categoria
--    inventario.id_bodega
--    pedido.id_cliente
--    pedido_detalle.id_producto
--  Cuales son un problema real: solo las que apuntan a un padre del que se borran filas. Sin borrados de padre no hay bloqueo de tabla.
--  No son problema: producto.id_categoria, inventario.id_bodega. El bloqueo de tabla solo aparece cuando borras una fila del padre.
--  Si nadie borra el padre, el bloqueo nunca se activa

-- #####################################################################
-- EJERCICIO 1.6 (si alcanza el tiempo) — Interbloqueo
-- #####################################################################

-- PASO 1  (A)  Reservo el producto 100
UPDATE inventario SET reservado = reservado + 1
 WHERE id_producto = 100 AND id_bodega = 1;

-- ... conexión B, PASO 2: reserva el producto 200 ...

-- PASO 3  (A)  Ahora pido el 200, que B tiene tomado
UPDATE inventario SET reservado = reservado + 1
 WHERE id_producto = 200 AND id_bodega = 1;
--> Me quedo esperando.

-- ... conexión B, PASO 4: pide el 100 -> ciclo cerrado ...

--> En segundos, UNA de las dos recibe:
--     ORA-00060: deadlock detected while waiting for resource

ROLLBACK;
--
--  PREGUNTA 1.11 — Oracle abortó UNA sentencia, no la transacción
--  completa. ¿En qué estado queda la sesión víctima y qué debe hacer?
-- RTA:/ En nuestro ejercicio A fue la victima, recibio el ORA-00060.
-- A queda con su transaccion abierta y todavia con el bloqueo del producto 100 puesto, estorbando.
-- debe hacer un ROLLBACK para soltar todo y volver a empezar la operacion completa.
-- no debe repetir la segunda sentencia, porque repetira el circulo.


--  PREGUNTA 1.12 — Escriba la regla de diseño, en una frase, que habría
--  hecho imposible este interbloqueo.

-- RTA:/Se debe reservar las filas de manera ordenada; si todos siguen esa regla, se evitan los ciclos,
-- ya que simplemente las actualizaciones se harian de manera secuencial esperando que una persona
-- termine para que la otra pueda seguir.
