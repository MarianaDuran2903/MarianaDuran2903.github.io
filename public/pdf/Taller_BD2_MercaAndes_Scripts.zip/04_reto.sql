-- =====================================================================
-- Bases de Datos 2 · Taller integrador — MercaAndes
-- 04_reto.sql   Reto final (25 minutos)
--
-- Trabajen en UNA SOLA CONEXI—N: la pareja comparte el esquema.
-- Este es el ejercicio que se entrega. Trabajen en pareja.
-- Todo se resuelve con SQL. No se necesita PL/SQL.
-- =====================================================================

-- ---------------------------------------------------------------------
-- EL TICKET
--
--   De:    Jefe de Operaciones, MercaAndes
--   Para:  Equipo de Base de Datos
--   Asunto: URGENTE — problemas en confirmación de pedidos
--
--   "Tenemos tres problemas desde el Black Friday:
--
--    1. Estamos vendiendo más unidades de las que hay en bodega. El
--       inventario del sistema no coincide con el físico y ya nos tocó
--       cancelar 40 pedidos.
--
--    2. Cuando la confirmación falla a la mitad, quedan pedidos en
--       estado PAGADO con el inventario ya descontado, o al revés.
--       Nadie sabe cuáles.
--
--    3. El tablero de la gerencia se demora casi un minuto en abrir.
--
--    Adjunto la secuencia de sentencias que ejecuta la aplicación cada
--    vez que un cliente paga, y la consulta del tablero. Necesitamos un
--    diagnóstico y la corrección."
-- ---------------------------------------------------------------------


-- #####################################################################
-- PIEZA 1 — Lo que ejecuta la aplicación al confirmar un pedido
--
-- La aplicación arma este bloque de sentencias en tiempo de ejecución,
-- una por cada línea del pedido, y las manda en este orden.
-- Aquí está el caso real del pedido 950001, que tiene dos líneas:
-- el producto 100 con 3 unidades y el producto 200 con 2 unidades.
--
-- Ejecútelo tal como está y observe qué hace. NO lo corrija todavía.
-- #####################################################################

-- Deje el inventario en un valor conocido antes de probar
UPDATE inventario SET disponible = 10 WHERE id_producto IN (100,200) AND id_bodega = 1;
UPDATE pedido SET estado = 'CREADO' WHERE id_pedido = 950001;
COMMIT;


--- inicio de lo que ejecuta la aplicación -----------------------------

-- línea 1 del pedido: producto 100, 3 unidades
SELECT disponible FROM inventario WHERE id_producto = 100 AND id_bodega = 1;
--> la aplicación guarda ese número, le resta 3, y escribe el resultado:
UPDATE inventario SET disponible = 7 WHERE id_producto = 100 AND id_bodega = 1;
COMMIT;

-- línea 2 del pedido: producto 200, 2 unidades
SELECT disponible FROM inventario WHERE id_producto = 200 AND id_bodega = 1;
--> la aplicación guarda ese número, le resta 2, y escribe el resultado:
UPDATE inventario SET disponible = 8 WHERE id_producto = 200 AND id_bodega = 1;
COMMIT;

-- y al final marca el pedido
UPDATE pedido SET estado = 'PAGADO' WHERE id_pedido = 950001;
COMMIT;

--- fin de lo que ejecuta la aplicación --------------------------------


-- #####################################################################
-- PIEZA 2 — La consulta del tablero de gerencia
-- #####################################################################

SELECT c.ciudad,
       COUNT(DISTINCT p.id_pedido)              AS pedidos,
       ROUND(SUM(d.cantidad * d.precio_unit))   AS facturado,
       ROUND(AVG(p.total))                      AS ticket
  FROM pedido         p
  JOIN cliente        c ON c.id_cliente  = p.id_cliente
  JOIN pedido_detalle d ON d.id_pedido   = p.id_pedido
 WHERE TO_CHAR(p.fecha_pedido, 'YYYY-MM') = '2026-03'
   AND p.estado <> 'ANULADO'
 GROUP BY c.ciudad
 ORDER BY facturado DESC;



-- #####################################################################
-- LO QUE HAY QUE ENTREGAR
-- #####################################################################
--
-- A. DIAGN—STICO  (4 puntos)
--
--    Identifique CUATRO defectos en la secuencia de la PIEZA 1.
--    Para cada uno indique:
--      - qué sentencia o qué parte de la secuencia lo causa
--      - cuál de los tres síntomas del ticket produce
--      - qué pasa en producción con 200 confirmaciones por minuto
--
--    Pista: uno es de concurrencia, uno es de transaccionalidad, uno
--    hace que el problema pase inadvertido, y uno es de rendimiento.
--
--    Para el primero, reprodúzcalo: ejecuten la secuencia desde las DOS
--    conexiones sobre el mismo producto y muestren el resultado.

-- A. DIAGNOSTICO
--
-- Defecto 1 - Concurrencia
-- El SELECT lee el stock pero no lo bloquea, y despues el UPDATE escribe un
-- numero fijo que la aplicacion calculo aparte (SET disponible = 7). Si otra
-- confirmacion del mismo producto se cuela en el medio, la segunda le escribe
-- encima a la primera y esa venta desaparece. Es el sintoma 1 del ticket:
-- se venden mas unidades de las que hay. Con 200 confirmaciones por minuto
-- esos cruces pasan todo el tiempo, y el inventario del sistema termina
-- siempre por encima del que hay en bodega.
--
-- Defecto 2 - Transaccionalidad
-- Hay tres COMMIT, uno por cada linea. Cada uno es un punto sin retorno, asi
-- que la confirmacion deja de ser una sola operacion. Si el proceso se cae
-- despues del primero, el producto 100 quedo descontado, el 200 no, y el
-- pedido sigue en CREADO. Ya no se puede deshacer nada. Es el sintoma 2, y
-- en produccion basta una caida o un timeout para dejar un pedido a medias.
--
-- Defecto 3 - El que hace que nadie se entere
-- Ninguna sentencia revisa cuantas filas afecto ni si alcanzaba el stock, y
-- el UPDATE del pedido tampoco verifica que estuviera en CREADO, asi que un
-- pedido se puede pagar dos veces. Como el valor lo pone la aplicacion y
-- siempre es positivo,como el valor lo calcula la aplicacion y lo escribe ya listo, el CHECK
-- (disponible >= 0) que si existe en la tabla nunca llega a evaluarse: le
-- llega un numero positivo y lo aprueba. La proteccion esta puesta, pero la
-- forma de escribir el UPDATE la esquiva. Este defecto no causa un sintoma
-- propio, lo que hace es tapar los otros dos. Por eso el problema aparecio
-- contando en bodega y no en un log de errores.
--
-- Defecto 4 - Rendimiento
-- La aplicacion manda un SELECT y un UPDATE por cada linea del pedido, en
-- viajes separados, y confirma en cada paso. Va de a una fila cuando podria
-- hacerlo todo en una sola sentencia. Con 200 confirmaciones por minuto eso
-- son cientos de sentencias y de COMMIT por minuto, y cada COMMIT obliga a
-- escribir en disco. Ademas la secuencia dura mas, que es justo cuando el
-- defecto 1 tiene chance de aparecer.
--
--
-- B. CORRECCI—N  (4 puntos)
--
--    Reescriba la secuencia usando SQL. Debe cumplir las cuatro cosas:
--      1. que dos confirmaciones simultáneas del mismo producto no
--         puedan perder unidades
--      2. que sea atómica: o se confirma todo el pedido, o nada
--      3. que se note cuando algo no se aplicó, en lugar de pasar en
--         silencio
--      4. que no permita dejar el inventario en negativo
--
--    Debe resolverse con las herramientas que ya vieron hoy:
--      - SELECT ... FOR UPDATE   (parte 1)
--      - UPDATE ... SET col = col - n
--      - MERGE                   (parte 3)
--      - un solo COMMIT al final
--      - la restricción CHECK que ya tiene la tabla INVENTARIO
--
--    Demuéstrelo: ejecute su versión desde las DOS conexiones al mismo
--    tiempo sobre el mismo producto y muestre que el resultado es
--    correcto. Documente cómo lo probó.

-- Dejar el escenario en un valor conocido para poder probar
UPDATE inventario SET disponible = 10 WHERE id_producto IN (100,200) AND id_bodega = 1;
UPDATE pedido SET estado = 'CREADO' WHERE id_pedido = 950001;
COMMIT;

--- secuencia corregida ------------------------------------------------

-- 1. Bloquear TODAS las filas de inventario del pedido, en orden fijo
SELECT i.id_producto, i.disponible
  FROM inventario i
  JOIN pedido_detalle d ON d.id_producto = i.id_producto
 WHERE d.id_pedido = 950001
   AND i.id_bodega = 1
 ORDER BY i.id_producto
   FOR UPDATE OF i.disponible;

-- 2. Descontar TODO el pedido con UNA sola sentencia de conjunto
MERGE INTO inventario i
USING (SELECT id_producto, SUM(cantidad) AS cantidad
         FROM pedido_detalle
        WHERE id_pedido = 950001
        GROUP BY id_producto) d
   ON (i.id_producto = d.id_producto AND i.id_bodega = 1)
 WHEN MATCHED THEN
   UPDATE SET i.disponible = i.disponible - d.cantidad,
              i.version    = i.version + 1;
--> Debe decir "2 filas fusionadas". Si dice menos, ROLLBACK.

-- 3. Marcar el pedido SOLO si estaba en CREADO
UPDATE pedido
   SET estado = 'PAGADO'
 WHERE id_pedido = 950001
   AND estado    = 'CREADO';
--> Debe decir "1 fila actualizada". Si dice 0, alguien ya lo pagó: ROLLBACK.

-- 4. Un solo COMMIT
COMMIT;
--
--
-- C. OPTIMIZACI—N DE LA CONSULTA  (1 punto)
--
--      - Capture el plan actual y anote COST y consistent gets
--      - Identifique qué impide el uso del índice
--      - Reescriba la consulta y/o cree el índice necesario
--      - Capture el plan nuevo y anote la mejora
--      - Justifique el índice: qué consulta lo usa y por qué no bastaba
--        con los que ya existen
--  RTA/:
--
-- PLAN ACTUAL:  COST = 941   consistent gets = 3295
-- PEDIDO entra con TABLE ACCESS FULL, leyendo las 200.000 filas para
-- devolver solo unos 3.946 pedidos de marzo.
--
-- QUE IMPIDE EL USO DEL INDICE:
-- En la seccion de predicados del plan aparece:
--   TO_CHAR(INTERNAL_FUNCTION(P.FECHA_PEDIDO),'YYYY-MM')='2026-03'
-- El TO_CHAR le cambia el valor a la columna. El indice guarda la fecha tal
-- cual, no convertida a texto, asi que Oracle no puede buscar ahi el valor
-- '2026-03' y le toca leer cada fila, convertirla y comparar.
-- Es el mismo error del ejercicio 2.2, esta vez con fechas.
--
-- CORRECCION: cambiar el TO_CHAR por un rango de fechas, dejando la columna
-- sin funciones encima. El < en vez de <= es porque el tipo DATE incluye la
-- hora, y con <= se perderian los pedidos del 31 de marzo despues de las
-- 00:00.

-- Consulta corregida
SELECT c.ciudad,
       COUNT(DISTINCT p.id_pedido)              AS pedidos,
       ROUND(SUM(d.cantidad * d.precio_unit))   AS facturado,
       ROUND(AVG(p.total))                      AS ticket
  FROM pedido         p
  JOIN cliente        c ON c.id_cliente  = p.id_cliente
  JOIN pedido_detalle d ON d.id_pedido   = p.id_pedido
 WHERE p.fecha_pedido >= DATE '2026-03-01'
   AND p.fecha_pedido <  DATE '2026-04-01'
   AND p.estado <> 'ANULADO'
 GROUP BY c.ciudad
 ORDER BY facturado DESC;
--
-- PLAN NUEVO:   COST = __938____   consistent gets = ___3295___
--
-- RESULTADO DE LA CORRECCION:
-- Con el filtro escrito como rango, la columna queda limpia y el indice ya
-- se puede usar. Aun asi el optimizador prefirio el FULL SCAN, y hace bien:
-- IX_PEDIDO_FECHA_ESTADO tiene clustering factor 200.001, igual a NUM_ROWS,
-- o sea que cada entrada del indice apunta a un bloque distinto. Traer las
-- ~9.395 filas de marzo por ahi serian 9.395 lecturas sueltas contra 479 de
-- leer la tabla de corrido.
-- La diferencia de fondo: antes el indice era imposible de usar, ahora es
-- posible pero no conviene. El TO_CHAR bloqueaba cualquier optimizacion.
--
-- POR QUE NO SE CREA OTRO INDICE:
-- Uno de cobertura sobre (fecha_pedido, estado, id_cliente, total) si
-- bajaria el costo, porque evitaria tocar la tabla. No se propone porque
-- PEDIDO es la tabla que mas escrituras recibe y en el ejercicio 2.5 medimos
-- que los indices multiplican por 5 el tiempo de insercion. Para un tablero
-- que se abre unas pocas veces al dia, no compensa.

EXPLAIN PLAN FOR
SELECT /*+ INDEX(p ix_pedido_fecha_estado) */
       c.ciudad, COUNT(DISTINCT p.id_pedido),
       ROUND(SUM(d.cantidad * d.precio_unit)), ROUND(AVG(p.total))
  FROM pedido p
  JOIN cliente c ON c.id_cliente = p.id_cliente
  JOIN pedido_detalle d ON d.id_pedido = p.id_pedido
 WHERE p.fecha_pedido >= DATE '2026-03-01'
   AND p.fecha_pedido <  DATE '2026-04-01'
   AND p.estado <> 'ANULADO'
 GROUP BY c.ciudad;
SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST +ROWS'));

-- en el plan anterior se ve como al forzar el uso del indice aumenta muchisimo el costo por el clustering factor,
--  por eso es que el optimizador sigue viendo como a mejor opcion el table access full ignorando el indice.


-- 1. Clustering factor de cada indice frente al tamaño real de la tabla
SELECT i.index_name,
       i.clustering_factor,
       i.num_rows,
       t.blocks AS bloques_tabla,
       ROUND(i.clustering_factor / t.blocks, 1) AS veces_peor_que_lo_ideal
  FROM user_indexes i
  JOIN user_tables  t ON t.table_name = i.table_name
 WHERE i.table_name = 'PEDIDO'
 ORDER BY i.clustering_factor;
-- se ve que el clustering factor es enorme empeorando el uso del indice y la unica forma de arreglar eso es reincertando los datos de manera ordenada en la tabla,
-- lo cual llevaria mucho tiempo y traeria otros problemas.

--
-- D. UNA RECOMENDACI—N  (1 punto)
--
--    En un párrafo: ¿qué le diría al jefe de Operaciones para que este
--    problema no vuelva a aparecer? No hable de esta consulta ni de
--    estas sentencias: hable de la práctica que hay que cambiar.

-- RTA/:
-- El problema no es un pedido en particular, sino donde estan guardadas las
-- reglas del negocio. Hay tres que no se pueden romper nunca: que el
-- inventario no quede en negativo, que un pedido no se pague dos veces, y
-- que descontar el inventario y marcar el pedido pasen siempre juntos o
-- ninguno de los dos. Hoy esas reglas estan escritas dentro del codigo de
-- cada canal (la tienda web, la app, el call center y los procesos de
-- bodega), y todos escriben sobre las mismas tablas. Cada equipo las
-- interpreta a su manera, asi que basta con que uno la haga mal para
-- descuadrar el inventario de todos, y ningun otro se entera.
-- Lo que hay que cambiar es eso: las tres reglas deben estar en la base de
-- datos, que es el unico punto por donde pasan todos los canales, y cada
-- confirmacion de pago debe guardarse completa o no guardarse, avisando
-- cuando algo no se pudo aplicar en vez de seguir callada. Ademas hay que
-- cambiar como se prueba: hoy se prueba con un usuario a la vez y asi todo
-- funciona, pero el error solo aparece cuando varios clientes compran el
-- mismo producto al mismo tiempo, y eso hay que probarlo antes de cada
-- temporada alta.
--
--
-- FORMATO DE ENTREGA
--   Un archivo .sql con la secuencia corregida y la consulta optimizada,
--   más un documento corto con las respuestas a A y D y las capturas de
--   los planes de ejecución del punto C.
-- #####################################################################


-- ---------------------------------------------------------------------
-- Zona de trabajo: escriba aquí su versión corregida
-- ---------------------------------------------------------------------

-- Sugerencia de estructura, para que no se pierdan:
--
--   1. Bloquee primero las filas de inventario que va a tocar,
--      SIEMPRE en el mismo orden.
--   2. Descuente el inventario con UNA sola sentencia de conjunto.
--   3. Marque el pedido.
--   4. Revise cuántas filas afectó cada sentencia antes de confirmar.
--   5. Un solo COMMIT al final; si algo salió mal, ROLLBACK.
