-- =====================================================================
-- Bases de Datos 2 · Taller integrador — MercaAndes
-- 03_sql_avanzado.sql   SQL analítico, jerárquico y MERGE
--
-- Trabajen en UNA SOLA CONEXI—N: la pareja comparte el esquema.
-- Cada bloque trae una consulta RESUELTA que sirve de modelo, y una
-- consulta que ustedes deben ESCRIBIR. Complete las que dicen ESCRIBA.
-- =====================================================================

SET LINESIZE 220
SET PAGESIZE 60
SET TIMING ON


-- #####################################################################
-- EJERCICIO 3.1 — Ranking dentro de grupos
--
-- Comercial quiere los 3 productos que más facturaron en cada categoría
-- durante 2026, solo contando pedidos que no fueron anulados.
-- #####################################################################

-- MODELO (resuelto)
WITH ventas AS (
  SELECT pr.id_categoria,
         pr.id_producto,
         pr.nombre,
         SUM(d.cantidad * d.precio_unit) AS facturado
    FROM pedido p
    JOIN pedido_detalle d ON d.id_pedido   = p.id_pedido
    JOIN producto       pr ON pr.id_producto = d.id_producto
   WHERE p.fecha_pedido >= DATE '2026-01-01'
     AND p.fecha_pedido <  DATE '2027-01-01'
     AND p.estado <> 'ANULADO'
   GROUP BY pr.id_categoria, pr.id_producto, pr.nombre
)
SELECT id_categoria, nombre, facturado, puesto
  FROM (SELECT v.*,
               RANK() OVER (PARTITION BY id_categoria
                                  ORDER BY facturado DESC) AS puesto
          FROM ventas v)
 WHERE puesto <= 3
 ORDER BY id_categoria, puesto;

--
--  PREGUNTA 3.1 — Cambie DENSE_RANK por RANK y luego por ROW_NUMBER.
--  Explique en qué se diferencian los tres cuando hay empates, y cuál
--  usaría usted para un "top 3" que debe devolver exactamente 3 filas.
--
--  RTA 3.1/: Los tres numeran, pero se comportan distinto ante empates.
--  Un ejemplo con 10, 2, 2, 1:
--    ROW_NUMBER -> 1, 2, 3, 4   (nunca repite, desempata arbitrariamente)
--    RANK       -> 1, 2, 2, 4   (empata y deja hueco)
--    DENSE_RANK -> 1, 2, 2, 3   (empata y no deja hueco)
--  Para un top 3 que debe devolver EXACTAMENTE 3 filas se usa ROW_NUMBER,
--  porque es el unico que garantiza numeros unicos. Con DENSE_RANK o RANK,
--  un triple empate en el tercer puesto devolveria 5 filas.
--
--  ESCRIBA 3.1 — La misma consulta, pero mostrando además qué porcentaje
--  representa cada producto sobre el total facturado de su categoría.
--  Use RATIO_TO_REPORT o una función de ventana con SUM() OVER.

WITH ventas AS (
  SELECT pr.id_categoria, pr.id_producto, pr.nombre,
         SUM(d.cantidad * d.precio_unit) AS facturado
    FROM pedido p
    JOIN pedido_detalle d  ON d.id_pedido    = p.id_pedido
    JOIN producto       pr ON pr.id_producto = d.id_producto
   WHERE p.fecha_pedido >= DATE '2026-01-01'
     AND p.fecha_pedido <  DATE '2027-01-01'
     AND p.estado <> 'ANULADO'
   GROUP BY pr.id_categoria, pr.id_producto, pr.nombre
)
SELECT id_categoria, nombre, ROUND(facturado) AS facturado, puesto,
       ROUND(pct_categoria, 2) AS pct_categoria
  FROM (SELECT v.*,
               DENSE_RANK() OVER (PARTITION BY id_categoria
                                  ORDER BY facturado DESC) AS puesto,
               100 * RATIO_TO_REPORT(facturado)
                       OVER (PARTITION BY id_categoria)    AS pct_categoria
          FROM ventas v)
 WHERE puesto <= 3
 ORDER BY id_categoria, puesto;
-- #####################################################################
-- EJERCICIO 3.2 — Series de tiempo: acumulado y variación
--
-- Gerencia quiere la evolución mensual de ventas de 2026, con el
-- acumulado del año y el crecimiento contra el mes anterior.
-- #####################################################################

-- MODELO (resuelto)
WITH mensual AS (
  SELECT TRUNC(fecha_pedido, 'MM') AS mes,
         SUM(total)                AS ventas,
         COUNT(*)                  AS pedidos
    FROM pedido
   WHERE fecha_pedido >= DATE '2026-01-01'
     AND fecha_pedido <  DATE '2027-01-01'
     AND estado <> 'ANULADO'
   GROUP BY TRUNC(fecha_pedido, 'MM')
)
SELECT TO_CHAR(mes,'YYYY-MM')                          AS mes,
       pedidos,
       ROUND(ventas)                                   AS ventas,
       ROUND(SUM(ventas) OVER (ORDER BY mes
             ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)) AS acumulado,
       ROUND(LAG(ventas) OVER (ORDER BY mes))          AS mes_anterior,
       ROUND(100 * (ventas - LAG(ventas) OVER (ORDER BY mes))
                 / NULLIF(LAG(ventas) OVER (ORDER BY mes),0), 1) AS var_pct
  FROM mensual
 ORDER BY mes;

--
--  PREGUNTA 3.2 — ¿Qué diferencia hay entre
--     ROWS  BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
--  y  RANGE BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW ?
--  Constrúyase un caso donde den resultados distintos.
--
--  RTA 3.2/: ROWS cuenta filas, RANGE cuenta valores. Con ROWS, "las 2
--  anteriores y la actual" son 3 filas y ya. Con RANGE, si hay filas que
--  tienen el mismo valor en el ORDER BY, las mete todas en la ventana.
--  Por eso solo dan distinto cuando hay empates: si hubiera dos filas del
--  mismo mes, con ROWS cada una ve su propio acumulado y con RANGE las dos
--  ven el mismo total. Aqui no se nota porque el GROUP BY deja un solo mes
--  por fila, o sea que no hay empates.

--  ESCRIBA 3.2 — Agregue una columna con el promedio móvil de los
--  últimos 3 meses (mes actual y los dos anteriores).

WITH mensual AS (
  SELECT TRUNC(fecha_pedido, 'MM') AS mes,
         SUM(total)                AS ventas,
         COUNT(*)                  AS pedidos
    FROM pedido
   WHERE fecha_pedido >= DATE '2026-01-01'
     AND fecha_pedido <  DATE '2027-01-01'
     AND estado <> 'ANULADO'
   GROUP BY TRUNC(fecha_pedido, 'MM')
)
SELECT TO_CHAR(mes,'YYYY-MM')                          AS mes,
       pedidos,
       ROUND(ventas)                                   AS ventas,
       ROUND(SUM(ventas) OVER (ORDER BY mes
             ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)) AS acumulado,
       ROUND(LAG(ventas) OVER (ORDER BY mes))          AS mes_anterior,
       ROUND(100 * (ventas - LAG(ventas) OVER (ORDER BY mes))
                 / NULLIF(LAG(ventas) OVER (ORDER BY mes),0), 1) AS var_pct,
               ROUND(AVG(ventas) OVER (ORDER BY mes
             ROWS BETWEEN 2 PRECEDING AND CURRENT ROW)) AS prom_movil_3m
  FROM mensual
 ORDER BY mes;
-- #####################################################################
-- EJERCICIO 3.3 — La misma respuesta, dos planes muy distintos
--
-- Se necesita, por cada cliente PREMIUM, su último pedido.
-- #####################################################################

-- VERSI—N A — subconsulta correlacionada  (la que sale sola al escribir)
EXPLAIN PLAN FOR
SELECT c.id_cliente, c.nombre, p.id_pedido, p.fecha_pedido, p.total
  FROM cliente c
  JOIN pedido  p ON p.id_cliente = c.id_cliente
 WHERE c.segmento = 'PREMIUM'
   AND p.fecha_pedido = (SELECT MAX(p2.fecha_pedido)
                           FROM pedido p2
                          WHERE p2.id_cliente = c.id_cliente);

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST +ROWS'));

-- VERSI—N B — función analítica
EXPLAIN PLAN FOR
SELECT id_cliente, nombre, id_pedido, fecha_pedido, total
  FROM (SELECT c.id_cliente, c.nombre, p.id_pedido, p.fecha_pedido, p.total,
               ROW_NUMBER() OVER (PARTITION BY c.id_cliente
                                  ORDER BY p.fecha_pedido DESC) AS rn
          FROM cliente c
          JOIN pedido  p ON p.id_cliente = c.id_cliente
         WHERE c.segmento = 'PREMIUM')
 WHERE rn = 1;

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST +ROWS'));

--
--  PREGUNTA 3.3 — Compare los dos planes. ¿Cuántas veces se lee PEDIDO
--  en cada versión? ¿Cuál es el COST de cada una?

--  RTA 3.3/: PEDIDO se lee 1 vez en cada version: en los dos planes hay un
--  solo TABLE ACCESS FULL PEDIDO con 200.011 filas. En la version A se
--  esperarian dos lecturas por la subconsulta correlacionada, pero el
--  optimizador la transformo internamente en funcion de ventana: por eso su
--  plan muestra VW_WIF_1, un WINDOW SORT y el filtro VW_COL_6 IS NOT NULL,
--  que no aparecen en la consulta escrita.
--  COST version A = 1217 (WINDOW SORT)
--  COST version B = 1109 (WINDOW SORT PUSHED RANK)
--
--  PREGUNTA 3.4 — Las dos consultas NO son totalmente equivalentes:
--  hay un caso en el que devuelven distinto número de filas. ¿Cuál es?
--  (pista: piense en dos pedidos del mismo cliente el mismo día)

--  RTA 3.4/: Cuando un cliente tiene DOS pedidos con la misma fecha_pedido
--  y esa es su fecha maxima. La version A devuelve los dos, porque ambos
--  cumplen fecha_pedido = MAX(...). La version B devuelve uno solo, porque
--  ROW_NUMBER = 1 escoge uno arbitrariamente entre los empatados. Para que
--  B se comportara como A habria que usar RANK() en vez de ROW_NUMBER().


-- #####################################################################
-- EJERCICIO 3.4 — Jerarquías: la CTE recursiva
--
-- El catálogo tiene categorías anidadas en tres niveles.
-- #####################################################################

-- MODELO (resuelto) — ruta completa de cada categoría
WITH arbol (id_categoria, nombre, id_padre, nivel, ruta) AS (
  SELECT id_categoria, nombre, id_padre, 1, CAST(nombre AS VARCHAR2(400))
    FROM categoria
   WHERE id_padre IS NULL
  UNION ALL
  SELECT c.id_categoria, c.nombre, c.id_padre, a.nivel + 1,
         a.ruta || ' > ' || c.nombre
    FROM categoria c
    JOIN arbol a ON c.id_padre = a.id_categoria
)
SELECT LPAD(' ', (nivel-1)*3) || nombre AS jerarquia, nivel, ruta
  FROM arbol
 ORDER BY ruta;

-- El equivalente con CONNECT BY, sintaxis propia de Oracle
SELECT LPAD(' ', (LEVEL-1)*3) || nombre AS jerarquia,
       LEVEL AS nivel,
       SYS_CONNECT_BY_PATH(nombre, ' > ') AS ruta
  FROM categoria
 START WITH id_padre IS NULL
CONNECT BY PRIOR id_categoria = id_padre
 ORDER SIBLINGS BY nombre;

--
--  PREGUNTA 3.5 — ¿Qué ventaja tiene la CTE recursiva sobre CONNECT BY?
--  ¿Y qué le da CONNECT BY que la CTE no?

--  RTA 3.5/: Funcionan distinto. La CTE recursiva trabaja por niveles: se
--  arranca con una consulta base (las categorias sin padre) y esa consulta
--  se vuelve a ejecutar contra el resultado anterior, sacando un nivel
--  completo en cada vuelta hasta que ya no salen filas nuevas. CONNECT BY
--  en cambio recorre rama por rama: baja por un hijo hasta el fondo, vuelve
--  y sigue con el siguiente.
--  De ahi salen las diferencias. Como la CTE es un SELECT normal repetido,
--  se le pueden meter joins con otras tablas y calcular las columnas que
--  uno quiera, pero todo hay que armarlo a mano: en el modelo tocó declarar
--  'nivel' y 'ruta' e irlas acumulando en cada vuelta. CONNECT BY, al ir
--  bajando por la rama, siempre sabe a que profundidad va y por donde paso,
--  y por eso entrega LEVEL y SYS_CONNECT_BY_PATH sin que uno haga nada, y
--  puede ordenar hermanos con ORDER SIBLINGS BY. Como contra, es sintaxis
--  propia de Oracle y su parte recursiva es mas rigida.
--
--  ESCRIBA 3.3 — Facturación total de 2026 por categoría RA—Z.
--  Es decir: las ventas de "Portátiles" deben sumar dentro de
--  "Tecnología". Use la CTE recursiva para resolver a qué raíz pertenece
--  cada categoría hoja, y únala con las ventas.

WITH arbol (id_categoria, id_raiz, nombre_raiz) AS (
  SELECT id_categoria, id_categoria, nombre
    FROM categoria
   WHERE id_padre IS NULL
  UNION ALL
  SELECT c.id_categoria, a.id_raiz, a.nombre_raiz
    FROM categoria c
    JOIN arbol a ON c.id_padre = a.id_categoria
)
SELECT a.nombre_raiz,
       COUNT(DISTINCT p.id_pedido)            AS pedidos,
       ROUND(SUM(d.cantidad * d.precio_unit)) AS facturado
  FROM pedido p
  JOIN pedido_detalle d  ON d.id_pedido    = p.id_pedido
  JOIN producto       pr ON pr.id_producto = d.id_producto
  JOIN arbol          a  ON a.id_categoria = pr.id_categoria
 WHERE p.fecha_pedido >= DATE '2026-01-01'
   AND p.fecha_pedido <  DATE '2027-01-01'
   AND p.estado <> 'ANULADO'
 GROUP BY a.nombre_raiz
 ORDER BY facturado DESC;


-- #####################################################################
-- EJERCICIO 3.5 — MERGE: aplicar los ajustes de inventario
--
-- Bodega envía cada noche un archivo de ajustes: mermas e ingresos.
-- La tabla AJUSTE_INVENTARIO ya los tiene cargados.
-- #####################################################################

-- PASO 1  Antes
SELECT SUM(disponible) AS stock_total FROM inventario;
SELECT motivo, COUNT(*), SUM(delta) FROM ajuste_inventario GROUP BY motivo;

-- MODELO (resuelto)
MERGE INTO inventario i
USING (SELECT id_producto, id_bodega, SUM(delta) AS delta
         FROM ajuste_inventario
        GROUP BY id_producto, id_bodega) a
   ON (i.id_producto = a.id_producto AND i.id_bodega = a.id_bodega)
 WHEN MATCHED THEN
   UPDATE SET i.disponible = GREATEST(i.disponible + a.delta, 0),
              i.version    = i.version + 1
 WHEN NOT MATCHED THEN
   INSERT (i.id_producto, i.id_bodega, i.disponible, i.reservado, i.version)
   VALUES (a.id_producto, a.id_bodega, GREATEST(a.delta,0), 0, 0);

--> Mire el mensaje de SQL Developer: cuántas filas fusionó.
-- RTA/:500 filas fusionadas.
COMMIT;

-- PASO 2  Después
SELECT SUM(disponible) AS stock_total FROM inventario;

--
--  PREGUNTA 3.6 — ¿Por qué se agrupa la tabla de ajustes dentro del
--  USING en lugar de usarla directamente? ¿Qué error da Oracle si un
--  mismo (producto, bodega) aparece dos veces en el origen?
--
--  RTA 3.6/: Porque la tabla de ajustes puede traer varios movimientos del
--  mismo producto en la misma bodega, por ejemplo una merma y un ingreso.
--  MERGE necesita saber con que fila actualizar cada fila del inventario, y
--  si le llegan dos no sabe cual escoger. En ese caso no aplica ninguna:
--  falla toda la sentencia con el error ORA-30926.
--  Al agrupar con SUM(delta) queda una sola fila por producto y bodega, que
--  ademas es lo correcto: lo que se quiere aplicar es el saldo de todos los
--  movimientos, no uno de ellos.

--  PREGUNTA 3.7 — El GREATEST(..., 0) evita que el stock quede negativo.
--  ¿Es esa la forma correcta de resolverlo, o está escondiendo un
--  problema? ¿Qué haría usted en un sistema real?

--  RTA 3.7/: Lo esta escondiendo. Si el inventario tiene 3 unidades y llega
--  una merma de 10, el GREATEST guarda 0 y nadie se entera de que faltaron
--  7. La diferencia entre lo que dice el sistema y lo que hay fisicamente en
--  bodega se pierde sin dejar rastro.
--  En un sistema real yo dejaria que el ajuste falle la tabla ya tiene la
--  restriccion CHECK (disponible >= 0) para eso. Los ajustes que no cuadran
--  se separan de los que si, se guardan en una tabla de excepciones con su
--  motivo, y se le avisa a bodega para que haga conteo fisico.
--  La regla: un dato que no cuadra se reporta, no se redondea.

--
--  ESCRIBA 3.4 — Modifique el MERGE para que además registre en la
--  cláusula WHEN MATCHED ... DELETE las filas de inventario que queden
--  en cero y estén en una bodega distinta de la 1.

--  ESCRIBA 3.4 — MERGE que ademas borra las filas que quedan en cero
MERGE INTO inventario i
USING (SELECT id_producto, id_bodega, SUM(delta) AS delta
         FROM ajuste_inventario
        GROUP BY id_producto, id_bodega) a
   ON (i.id_producto = a.id_producto AND i.id_bodega = a.id_bodega)
 WHEN MATCHED THEN
   UPDATE SET i.disponible = GREATEST(i.disponible + a.delta, 0),
              i.version    = i.version + 1
   DELETE WHERE i.disponible = 0 AND i.id_bodega <> 1
 WHEN NOT MATCHED THEN
   INSERT (i.id_producto, i.id_bodega, i.disponible, i.reservado, i.version)
   VALUES (a.id_producto, a.id_bodega, GREATEST(a.delta,0), 0, 0);


-- #####################################################################
-- EJERCICIO 3.6 — PIVOT y LISTAGG
-- #####################################################################

-- MODELO (resuelto) — ventas por canal y trimestre, en columnas
SELECT *
  FROM (SELECT canal,
               'T' || TO_CHAR(fecha_pedido,'Q') AS trimestre,
               total
          FROM pedido
         WHERE fecha_pedido >= DATE '2026-01-01'
           AND fecha_pedido <  DATE '2027-01-01'
           AND estado <> 'ANULADO')
 PIVOT (ROUND(SUM(total)) FOR trimestre IN ('T1' AS t1, 'T2' AS t2,
                                            'T3' AS t3, 'T4' AS t4))
 ORDER BY canal;

-- MODELO (resuelto) — los 10 mejores clientes y qué categorías compraron
SELECT c.id_cliente, c.nombre,
       ROUND(SUM(d.cantidad * d.precio_unit)) AS facturado,
       LISTAGG(DISTINCT cat.nombre, ', ')
         WITHIN GROUP (ORDER BY cat.nombre) AS categorias
  FROM cliente c
  JOIN pedido         p   ON p.id_cliente   = c.id_cliente
  JOIN pedido_detalle d   ON d.id_pedido    = p.id_pedido
  JOIN producto       pr  ON pr.id_producto = d.id_producto
  JOIN categoria      cat ON cat.id_categoria = pr.id_categoria
 WHERE p.estado <> 'ANULADO'
 GROUP BY c.id_cliente, c.nombre
 ORDER BY facturado DESC
 FETCH FIRST 10 ROWS WITH TIES;

--
--  PREGUNTA 3.8 — ¿Qué diferencia hay entre FETCH FIRST 10 ROWS ONLY y
--  FETCH FIRST 10 ROWS WITH TIES? ¿En cuál de los dos casos puede
--  devolver más de 10 filas y por qué?

--  RTA 3.8/: ONLY corta en 10 filas exactas, sin importar si la fila 11
--  tiene el mismo valor que la 10. WITH TIES devuelve esas 10 mas todas las
--  que esten empatadas con la ultima segun la columna del ORDER BY.
--  El que puede devolver mas de 10 es WITH TIES: si el cliente numero 10 y
--  el 11 facturaron exactamente lo mismo, los trae a los dos, porque no
--  tiene forma de decidir cual dejar por fuera. Solo tiene sentido usarlo
--  con ORDER BY, que es lo que define el criterio del empate.
--
--  ESCRIBA 3.5 — Un informe de "clientes en riesgo": clientes PREMIUM
--  cuyo último pedido tiene más de 120 días, mostrando cuántos días
--  llevan sin comprar y cuánto facturaron históricamente.

--  ESCRIBA 3.5 — Clientes PREMIUM sin comprar hace mas de 120 dias
WITH actividad AS (
  SELECT id_cliente,
         MAX(fecha_pedido) AS ultima_compra,
         COUNT(*)          AS pedidos_historicos,
         SUM(total)        AS facturacion_historica
    FROM pedido
   WHERE estado <> 'ANULADO'
   GROUP BY id_cliente
)
SELECT c.id_cliente,
       c.nombre,
       c.ciudad,
       TRUNC(a.ultima_compra)                AS ultima_compra,
       TRUNC(SYSDATE - a.ultima_compra)      AS dias_inactivo,
       a.pedidos_historicos,
       ROUND(a.facturacion_historica)        AS facturado_historico
  FROM cliente   c
  JOIN actividad a ON a.id_cliente = c.id_cliente
 WHERE c.segmento = 'PREMIUM'
   AND a.ultima_compra < SYSDATE - 120
 ORDER BY dias_inactivo DESC;
