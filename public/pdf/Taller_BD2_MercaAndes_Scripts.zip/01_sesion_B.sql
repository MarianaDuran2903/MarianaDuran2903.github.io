-- =====================================================================
-- Bases de Datos 2 · Taller integrador — MercaAndes
-- 01_sesion_B.sql        >>>  CONEXI—N B  <<<
--
-- NO ejecute este archivo de corrido. Cada bloque dice PASO n:
-- ejecútelo con Ctrl+Enter cuando le toque, alternando con la conexión A.
--
-- ANTES DE EMPEZAR, verifique:
--   1. Autocommit APAGADO
--      Herramientas > Preferencias > Base de datos > Avanzado > Autoconfirmar
--   2. Que este SID sea DISTINTO al de la conexión A.
-- =====================================================================

SELECT 'CONEXI—N B' AS ventana, SYS_CONTEXT('USERENV','SID') AS sid FROM dual;


-- #####################################################################
-- EJERCICIO 1.1 — La venta que se pierde (actualización perdida)
-- #####################################################################

-- ... espere a que A haga sus PASOS 1 y 2 ...

-- PASO 3  (B)  "Mi aplicación" también leyó 10
SELECT id_producto, id_bodega, disponible
  FROM inventario WHERE id_producto = 100 AND id_bodega = 1;
--> ¿Qué valor ve? ¿Ve el 7 que A ya escribió pero no confirmó?
--  Anote la respuesta: es la lectura consistente de Oracle.

-- PASO 4  (B)  Leí 10 y calculé 10 - 4 = 6. Escribo.
UPDATE inventario SET disponible = 6
 WHERE id_producto = 100 AND id_bodega = 1;
--> ESTA SENTENCIA NO RESPONDE. Queda esperando el bloqueo de A.
--  Déjela corriendo y observe. NO la cancele.

-- ... A hace COMMIT en su PASO 5: aquí su UPDATE se destraba solo ...

-- PASO 6  (B)  Ya respondió. Confirmo mi venta de 4 unidades.
COMMIT;

-- PASO 7  (B)
SELECT id_producto, disponible FROM inventario
 WHERE id_producto = 100 AND id_bodega = 1;
--
--  Discutan con su pareja ANTES de mirar el resultado:
--  ¿debería quedar en 3 o en 6?


-- #####################################################################
-- EJERCICIO 1.2 — Defensa pesimista: SELECT ... FOR UPDATE
-- #####################################################################

-- ... A hizo su PASO 2: leyó Y bloqueó la fila ...

-- PASO 3  (B)  Intento leer con intención de escribir
SELECT id_producto, disponible
  FROM inventario
 WHERE id_producto = 100 AND id_bodega = 1
   FOR UPDATE;
--> Se bloquea. A tiene la fila reservada.

-- PASO 4  (B)  Compruebe algo importante: una lectura NORMAL sí pasa.
--   Abra una tercera hoja de trabajo sobre ESTA misma conexión y ejecute:
--     SELECT disponible FROM inventario
--      WHERE id_producto = 100 AND id_bodega = 1;
--   Responde de inmediato. Los lectores no se bloquean.

-- ... A hace UPDATE y COMMIT en su PASO 5 ...

-- PASO 6  (B)  Mi SELECT FOR UPDATE ya respondió, con el valor NUEVO.
--   Descuento mis 4 unidades sobre el valor actual, no sobre el que leí antes.
UPDATE inventario SET disponible = disponible - 4
 WHERE id_producto = 100 AND id_bodega = 1;
COMMIT;

-- PASO 7  (B)
SELECT id_producto, disponible FROM inventario
 WHERE id_producto = 100 AND id_bodega = 1;
--> 10 - 3 - 4 = 3.  Ninguna venta se perdió.


-- #####################################################################
-- EJERCICIO 1.3 — Defensa optimista: columna de versión
-- #####################################################################

-- ... A leyó disponible y version en su PASO 2. Nadie bloqueó nada ...

-- PASO 3  (B)  Leo lo mismo que A
SELECT id_producto, disponible, version
  FROM inventario WHERE id_producto = 100 AND id_bodega = 1;

-- PASO 4  (B)  Y escribo PRIMERO
UPDATE inventario
   SET disponible = disponible - 4,
       version    = version + 1
 WHERE id_producto = 100 AND id_bodega = 1
   AND version     = 0;
COMMIT;
--> 1 fila actualizada: gané la carrera. La versión pasó de 0 a 1.

-- ... A intenta su UPDATE con version = 0 y actualiza 0 filas ...

-- PASO 7  (B)
SELECT id_producto, disponible, version FROM inventario
 WHERE id_producto = 100 AND id_bodega = 1;
--
--  Nadie se bloqueó en ningún momento, y aun así no se perdió nada.
--  Ese es el trato del bloqueo optimista: cero espera, a cambio de
--  tener que reintentar cuando hay choque.


-- #####################################################################
-- EJERCICIO 1.4 — Repartir la cola de despacho: SKIP LOCKED
-- #####################################################################

-- ... A tomó 5 tareas en su PASO 1 y no ha confirmado ...

-- PASO 2  (B)  Pido 5 tareas
SELECT id_tarea, id_pedido
  FROM tarea_despacho
 WHERE estado = 'PENDIENTE'
   AND ROWNUM <= 5
   FOR UPDATE SKIP LOCKED;
--  Nota de sintaxis: aquí se usa ROWNUM y no FETCH FIRST ... ROWS ONLY.
--  Oracle implementa FETCH FIRST como una vista en línea, y combinarlo
--  con FOR UPDATE devuelve ORA-02014. Para una cola de trabajo ROWNUM es
--  además lo correcto: no importa CU—LES cinco tareas toma, importa que
--  sean cinco libres y que nadie más las tenga.
--> Son tareas DISTINTAS a las de A, y la consulta no esperó nada.
--  Anote los id_tarea que le tocaron.

-- PASO 4  (B)  Marco las mías
UPDATE tarea_despacho
   SET estado = 'PROCESADA', tomada_por = 'OPERARIO_B', fecha_toma = SYSTIMESTAMP
 WHERE id_tarea IN (6,7,8,9,10);     -- <-- reemplace por los ids que le tocaron
COMMIT;

-- PASO 6  (B)  Compare con A: no hay ni una tarea repetida.
SELECT estado, tomada_por, COUNT(*) FROM tarea_despacho
 GROUP BY estado, tomada_por ORDER BY 1,2;


-- #####################################################################
-- EJERCICIO 1.5 — El bloqueo que nadie espera: FK sin índice
-- #####################################################################

-- ... A insertó un pago del pedido 900001 y NO confirmó ...

-- PASO 2  (B)  Borro el pedido 900005.
--   Ese pedido NO tiene pagos ni detalle: no tiene nada que ver con A.
DELETE FROM pedido WHERE id_pedido = 900005;
--> SE BLOQUEA.
--  Sin índice sobre PAGO.ID_PEDIDO, Oracle protege la integridad tomando
--  un bloqueo de TABLA sobre el hijo.

-- ... A confirma en su PASO 4: aquí se destraba ...

-- PASO 5  (B)
ROLLBACK;

-- ... A crea el índice en su PASO 6 ...

-- (B)  Repitan el ejercicio completo desde el PASO 1 de A.
--   Ahora el DELETE responde de inmediato.


-- #####################################################################
-- EJERCICIO 1.6 (si alcanza el tiempo) — Interbloqueo
-- #####################################################################

-- ... A reservó el producto 100 en su PASO 1 ...

-- PASO 2  (B)  Reservo el producto 200
UPDATE inventario SET reservado = reservado + 1
 WHERE id_producto = 200 AND id_bodega = 1;

-- ... A pide el 200 en su PASO 3 y se queda esperando ...

-- PASO 4  (B)  Ahora yo pido el 100, que A tiene tomado
UPDATE inventario SET reservado = reservado + 1
 WHERE id_producto = 100 AND id_bodega = 1;
--> Ciclo cerrado: A espera a B y B espera a A.
--  En unos segundos, una de las dos recibe ORA-00060.

ROLLBACK;
