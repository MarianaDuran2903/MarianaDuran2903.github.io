-- =====================================================================
-- 03_template_entrega_taller1_v2.sql
-- Taller aplicado 1 - SQL avanzado + Transacciones (ACID) aplicado
-- Plantilla de entrega para estudiantes
--
-- IMPORTANTE:
-- 1. Trabajar únicamente sobre las tablas T1_% y AUDIT_SALARY_ADJUSTMENTS_T1
-- 2. NO modificar la estructura del entorno entregado por el docente
-- 3. NO eliminar secciones de esta plantilla
-- 4. Reemplazar únicamente los bloques indicados como "ESCRIBA AQUÍ"
-- 5. Usar la variante asignada por el docente (1, 2, 3 o 4)
-- 6. Usar un tag único de ejecución final, por ejemplo: P03_FINAL
-- =====================================================================

SET SERVEROUTPUT ON
SET FEEDBACK ON

-- ============================================================
-- 0. ENCABEZADO OBLIGATORIO
-- Complete toda esta información antes de ejecutar el script.
-- ============================================================
-- Integrante 1: __Santiago_Gomez_______________________________________
-- Integrante 2: __Mariana_Duran________________________________________
-- Integrante 3: __Gabriel_Amortegui________________________________________
-- Curso: _________Bases_de_datos_1________________________________________
-- Fecha: _________22/05/2026________________________________________
-- Variante asignada por el docente (1, 2, 3 o 4): ____3____
-- Tag de ejecución final (ejemplo: P03_FINAL): _____P01_FINAL_______

DEFINE p_variant_id = 1
DEFINE p_execution_tag = 'P01_FINAL'

PROMPT ===== 0. VERIFICACIÓN DE LA VARIANTE ASIGNADA =====
SELECT
    variant_id,
    variant_name,
    excluded_department_id,
    min_years_service,
    recent_job_history_months,
    gap_high_threshold_pct,
    gap_mid_threshold_pct,
    raise_high_pct,
    raise_mid_pct,
    raise_low_pct,
    max_salary_vs_avg_pct,
    notes
FROM t1_variants
WHERE variant_id = &p_variant_id;

-- ============================================================
-- GUÍA RÁPIDA DE OBJETOS DISPONIBLES
-- Use estos nombres reales de tablas y columnas.
-- ============================================================
-- Tabla principal de empleados: T1_EMPLOYEES
-- Columnas más importantes:
--   employee_id, first_name, last_name, email, phone_number,
--   hire_date, job_id, salary, commission_pct, manager_id, department_id
--
-- Tabla de departamentos: T1_DEPARTMENTS
-- Columnas más importantes:
--   department_id, department_name, manager_id, location_id
--
-- Tabla de historial laboral: T1_JOB_HISTORY
-- Columnas más importantes:
--   employee_id, start_date, end_date, job_id, department_id
--
-- Tabla de auditoría: AUDIT_SALARY_ADJUSTMENTS_T1
-- Columnas:
--   audit_id, execution_tag, variant_id, employee_id, department_id,
--   salary_before, salary_after, pct_gap_to_avg_before, rule_applied,
--   executed_by, executed_at, notes
--
-- Tabla de variantes: T1_VARIANTS
-- Columnas:
--   variant_id, variant_name, excluded_department_id, min_years_service,
--   recent_job_history_months, gap_high_threshold_pct,
--   gap_mid_threshold_pct, raise_high_pct, raise_mid_pct,
--   raise_low_pct, max_salary_vs_avg_pct, notes

-- ============================================================
-- GUÍA RÁPIDA DE TÉRMINOS QUE DEBE USAR EN SU SOLUCIÓN
-- ============================================================
-- CTE:
--   Una CTE es una consulta temporal escrita con WITH.
--   Sirve para dividir una consulta grande en partes más claras.
--
--   Ejemplo:
--   WITH dept_stats AS (
--       SELECT department_id, AVG(salary) avg_salary
--       FROM t1_employees
--       GROUP BY department_id
--   )
--   SELECT *
--   FROM dept_stats;
--
-- Función analítica:
--   Es una función como ROW_NUMBER, RANK o DENSE_RANK.
--   Sirve para calcular posiciones o comparaciones sin perder el detalle.
--
--   Ejemplo:
--   DENSE_RANK() OVER (PARTITION BY department_id ORDER BY salary DESC)
--
-- JOIN:
--   Es la unión entre tablas relacionadas, por ejemplo empleados y departamentos.
--
-- Subconsulta:
--   Es una consulta dentro de otra consulta.
--
-- SAVEPOINT:
--   Es un punto de restauración dentro de una transacción.
--   Permite devolver la operación a un punto intermedio con ROLLBACK TO.

-- ============================================================
-- 1. CONSULTA DIAGNÓSTICA
-- OBJETIVO:
-- Analizar la información antes de actualizar salarios.
--
-- SU CONSULTA DEBE MOSTRAR, COMO MÍNIMO, ESTAS COLUMNAS:
--   employee_id
--   first_name
--   last_name
--   job_id
--   manager_id
--   department_id
--   department_name
--   salary
--   hire_date
--   years_service
--   dept_avg_salary
--   dept_max_salary
--   dept_employee_count
--   pct_gap_to_avg
--   recent_job_history_flag
--   salary_rank_in_department
--
-- QUÉ SIGNIFICA CADA COLUMNA:
--   years_service: años de antigüedad del empleado
--   dept_avg_salary: promedio salarial del departamento
--   dept_max_salary: salario más alto del departamento
--   dept_employee_count: cantidad de empleados del departamento
--   pct_gap_to_avg: porcentaje que le falta al salario del empleado para llegar
--                   al promedio del departamento
--   recent_job_history_flag: SI o NO, según si tuvo historial reciente
--   salary_rank_in_department: posición salarial dentro del departamento
--
-- IMPORTANTE:
-- - Puede usar una o varias CTE
-- - Debe usar al menos una función analítica
-- - Debe unir como mínimo T1_EMPLOYEES con T1_DEPARTMENTS
-- - Debe revisar T1_JOB_HISTORY para detectar historial reciente
-- ============================================================

PROMPT ===== 1. CONSULTA DIAGNÓSTICA =====

-- ============================================================
-- 1. CONSULTA DIAGNÓSTICA
-- ============================================================

-- 1.1 Estadísticas por departamento
SELECT
    department_id,
    AVG(salary)   AS dept_avg_salary,
    MAX(salary)   AS dept_max_salary,
    COUNT(*)      AS dept_employee_count
FROM t1_employees
WHERE department_id IS NOT NULL
GROUP BY department_id
ORDER BY department_id;

-- 1.2 Empleados con historial reciente (variante 3 = 24 meses)
SELECT DISTINCT jh.employee_id
FROM t1_job_history jh, t1_variants v
WHERE v.variant_id = 3
  AND jh.end_date >= ADD_MONTHS(TRUNC(SYSDATE), -v.recent_job_history_months);

-- 1.3 Empleados sin departamento asignado
SELECT
    employee_id,
    first_name,
    last_name,
    department_id
FROM t1_employees
WHERE department_id IS NULL;
-- 1.4 Diagnóstico completo
WITH dept_stats AS (
    SELECT
        department_id,
        AVG(salary)   AS dept_avg_salary,
        MAX(salary)   AS dept_max_salary,
        COUNT(*)      AS dept_employee_count
    FROM t1_employees
    WHERE department_id IS NOT NULL
    GROUP BY department_id
),
recent_history AS (
    SELECT DISTINCT jh.employee_id
    FROM t1_job_history jh, t1_variants v
    WHERE v.variant_id = 3
      AND jh.end_date >= ADD_MONTHS(TRUNC(SYSDATE), -v.recent_job_history_months)
),
sin_departamento AS (
    SELECT employee_id
    FROM t1_employees
    WHERE department_id IS NULL
)
SELECT
    e.employee_id,
    e.first_name,
    e.last_name,
    e.job_id,
    e.manager_id,
    e.department_id,
    d.department_name,
    e.salary,
    e.hire_date,
    ROUND(MONTHS_BETWEEN(SYSDATE, e.hire_date) / 12, 1)      AS years_service,
    ds.dept_avg_salary,
    ds.dept_max_salary,
    ds.dept_employee_count,
    ROUND((ds.dept_avg_salary - e.salary)
          / ds.dept_avg_salary * 100, 2)                      AS pct_gap_to_avg,
    CASE WHEN rh.employee_id IS NOT NULL THEN 'SI'
         ELSE 'NO' END                                        AS recent_job_history_flag,
    CASE WHEN sd.employee_id IS NOT NULL THEN 'SI'
         ELSE 'NO' END                                        AS sin_departamento_flag,
    DENSE_RANK() OVER (
        PARTITION BY e.department_id
        ORDER BY e.salary DESC
    )                                                         AS salary_rank_in_department
FROM t1_employees e
LEFT JOIN t1_departments  d  ON e.department_id = d.department_id
LEFT JOIN dept_stats      ds ON e.department_id = ds.department_id
LEFT JOIN recent_history  rh ON e.employee_id   = rh.employee_id
LEFT JOIN sin_departamento sd ON e.employee_id  = sd.employee_id
ORDER BY e.department_id NULLS LAST, salary_rank_in_department;

-- COMENTARIO OBLIGATORIO:
-- La consulta diagnostica muestra el estado completo de cada empleado antes de realizar
-- cualquier modificacion. Permite ver la brecha salarial respecto al promedio del departamento,
-- los anos de antiguedad, si tuvo historial laboral reciente y su posicion dentro del area.
-- Con esta informacion se puede identificar desde el inicio quienes tienen alguna razon de
-- exclusion como no tener departamento, historial reciente o antiguedad insuficiente,
-- sin necesidad de modificar ningun dato todavia.

-- ============================================================
-- 2. DECISIÓN DE POBLACIÓN ELEGIBLE
-- OBJETIVO:
-- Determinar qué empleados sí califican, cuáles no califican y por qué.
--
-- SU CONSULTA DEBE MOSTRAR, COMO MÍNIMO, ESTAS COLUMNAS:
--   employee_id
--   first_name
--   last_name
--   department_id
--   department_name
--   salary
--   years_service
--   dept_avg_salary
--   dept_max_salary
--   dept_employee_count
--   pct_gap_to_avg
--   recent_job_history_flag
--   manager_or_exec_flag
--   eligibility_flag
--   exclusion_reason
--   adjustment_pct
--   rule_applied
--
-- QUÉ SIGNIFICA CADA COLUMNA:
--   manager_or_exec_flag: SI o NO, según si es gerente principal o alta dirección
--   eligibility_flag: ELEGIBLE o NO_ELEGIBLE
--   exclusion_reason: motivo de exclusión, por ejemplo:
--                     SIN_DEPARTAMENTO, HISTORIAL_RECIENTE,
--                     ANTIGUEDAD_INSUFICIENTE, MANAGER_O_DIRECTIVO,
--                     DEPTO_EXCLUIDO, DEPTO_MENOR_A_3, SALARIO_NO_APLICA
--   adjustment_pct: porcentaje de ajuste que le corresponde
--   rule_applied: regla aplicada, por ejemplo AJUSTE_ALTO, AJUSTE_MEDIO, AJUSTE_BAJO
--
-- IMPORTANTE:
-- - Debe tomar en cuenta la variante asignada por el docente
-- - Debe usar los valores de T1_VARIANTS según &p_variant_id
-- - Debe quedar visible por qué una persona sí o no entra al proceso
-- ============================================================

PROMPT ===== 2. DECISIÓN DE ELEGIBLES =====

WITH dept_stats AS (
    SELECT
        department_id,
        AVG(salary)  AS dept_avg_salary,
        MAX(salary)  AS dept_max_salary,
        COUNT(*)     AS dept_employee_count
    FROM t1_employees
    WHERE department_id IS NOT NULL
    GROUP BY department_id
),
recent_history AS (
    SELECT DISTINCT jh.employee_id
    FROM t1_job_history jh, t1_variants v
    WHERE v.variant_id = 3
      AND jh.end_date >= ADD_MONTHS(TRUNC(SYSDATE), -v.recent_job_history_months)
),
sin_departamento AS (
    SELECT employee_id
    FROM t1_employees
    WHERE department_id IS NULL
),
managers AS (
    SELECT DISTINCT manager_id AS employee_id
    FROM t1_departments
    WHERE manager_id IS NOT NULL
),
variante AS (
    SELECT
        excluded_department_id,
        min_years_service,
        gap_high_threshold_pct,
        gap_mid_threshold_pct,
        raise_high_pct,
        raise_mid_pct,
        raise_low_pct,
        max_salary_vs_avg_pct
    FROM t1_variants
    WHERE variant_id = 3
)
SELECT
    e.employee_id,
    e.first_name,
    e.last_name,
    e.department_id,
    d.department_name,
    e.salary,
    ROUND(MONTHS_BETWEEN(SYSDATE, e.hire_date) / 12, 1)        AS years_service,
    ds.dept_avg_salary,
    ds.dept_max_salary,
    ds.dept_employee_count,
    ROUND((ds.dept_avg_salary - e.salary)
          / ds.dept_avg_salary * 100, 2)                        AS pct_gap_to_avg,
    CASE WHEN rh.employee_id IS NOT NULL
         THEN 'SI' ELSE 'NO' END                                AS recent_job_history_flag,
    CASE WHEN m.employee_id IS NOT NULL
         THEN 'SI' ELSE 'NO' END                                AS manager_or_exec_flag,
    CASE
        WHEN e.department_id IS NULL                            THEN 'NO_ELEGIBLE'
        WHEN e.department_id = v.excluded_department_id         THEN 'NO_ELEGIBLE'
        WHEN ds.dept_employee_count < 3                         THEN 'NO_ELEGIBLE'
        WHEN ROUND(MONTHS_BETWEEN(SYSDATE, e.hire_date)
             / 12, 1) < v.min_years_service                     THEN 'NO_ELEGIBLE'
        WHEN rh.employee_id IS NOT NULL                         THEN 'NO_ELEGIBLE'
        WHEN m.employee_id IS NOT NULL                          THEN 'NO_ELEGIBLE'
        WHEN (ds.dept_avg_salary - e.salary) <= 0              THEN 'NO_ELEGIBLE'
        ELSE 'ELEGIBLE'
    END                                                         AS eligibility_flag,
    CASE
        WHEN e.department_id IS NULL                            THEN 'SIN_DEPARTAMENTO'
        WHEN e.department_id = v.excluded_department_id         THEN 'DEPTO_EXCLUIDO'
        WHEN ds.dept_employee_count < 3                         THEN 'DEPTO_MENOR_A_3'
        WHEN ROUND(MONTHS_BETWEEN(SYSDATE, e.hire_date)
             / 12, 1) < v.min_years_service                     THEN 'ANTIGUEDAD_INSUFICIENTE'
        WHEN rh.employee_id IS NOT NULL                         THEN 'HISTORIAL_RECIENTE'
        WHEN m.employee_id IS NOT NULL                          THEN 'MANAGER_O_DIRECTIVO'
        WHEN (ds.dept_avg_salary - e.salary) <= 0              THEN 'SALARIO_NO_APLICA'
        ELSE NULL
    END                                                         AS exclusion_reason,
    CASE
        WHEN ROUND((ds.dept_avg_salary - e.salary)
             / ds.dept_avg_salary * 100, 2) > v.gap_high_threshold_pct
            THEN v.raise_high_pct
        WHEN ROUND((ds.dept_avg_salary - e.salary)
             / ds.dept_avg_salary * 100, 2) > v.gap_mid_threshold_pct
            THEN v.raise_mid_pct
        ELSE v.raise_low_pct
    END                                                         AS adjustment_pct,
    CASE
        WHEN ROUND((ds.dept_avg_salary - e.salary)
             / ds.dept_avg_salary * 100, 2) > v.gap_high_threshold_pct
            THEN 'AJUSTE_ALTO'
        WHEN ROUND((ds.dept_avg_salary - e.salary)
             / ds.dept_avg_salary * 100, 2) > v.gap_mid_threshold_pct
            THEN 'AJUSTE_MEDIO'
        ELSE 'AJUSTE_BAJO'
    END                                                         AS rule_applied
FROM t1_employees e
LEFT JOIN t1_departments d   ON e.department_id = d.department_id
LEFT JOIN dept_stats     ds  ON e.department_id = ds.department_id
LEFT JOIN recent_history rh  ON e.employee_id   = rh.employee_id
LEFT JOIN managers       m   ON e.employee_id   = m.employee_id
CROSS JOIN variante      v
ORDER BY eligibility_flag, e.department_id NULLS LAST;

-- COMENTARIO OBLIGATORIO:
-- La decision de elegibles aplica las reglas de la variante 3 leidas desde T1_VARIANTS,
-- sin usar valores fijos en el codigo. Se evaluaron siete razones de exclusion en orden:
-- sin departamento, departamento excluido (100), departamento con menos de 3 empleados,
-- antiguedad menor a 4 anos, historial reciente en los ultimos 24 meses, ser manager
-- principal de algun departamento, y salario ya igual o superior al promedio del area.
-- Solo los empleados que superan todas las exclusiones quedan como ELEGIBLES y reciben
-- un porcentaje de ajuste segun su brecha respecto al promedio del departamento.

-- ============================================================
-- 3. PREVALIDACIÓN ANTES DE LA TRANSACCIÓN
-- OBJETIVO:
-- Mostrar qué pasaría antes de ejecutar el cambio real.
--
-- DEBE MOSTRAR, COMO MÍNIMO:
-- A. Un resumen con estas columnas:
--    total_eligible_employees
--    total_salary_before
--    total_salary_after
--    total_increment
--
-- B. Un detalle de empleados elegibles con estas columnas:
--    employee_id
--    department_id
--    salary_before
--    salary_after
--    adjustment_pct
--    rule_applied
--
-- C. Un control de topes por departamento con estas columnas:
--    department_id
--    department_name
--    dept_avg_salary
--    dept_max_salary
--    max_allowed_salary_by_variant
--
-- QUÉ SIGNIFICA:
--   total_salary_before: suma de salarios antes del ajuste
--   total_salary_after: suma de salarios proyectados después del ajuste
--   total_increment: incremento total proyectado
--   max_allowed_salary_by_variant: salario máximo permitido según la variante
-- ============================================================

PROMPT ===== 3. PREVALIDACIÓN =====

-- CTE base que se reutiliza en las 3 consultas de prevalidacion
-- 3.1 Resumen general
WITH dept_stats AS (
    SELECT department_id, AVG(salary) AS dept_avg_salary,
           MAX(salary) AS dept_max_salary, COUNT(*) AS dept_employee_count
    FROM t1_employees WHERE department_id IS NOT NULL
    GROUP BY department_id
),
recent_history AS (
    SELECT DISTINCT jh.employee_id FROM t1_job_history jh, t1_variants v
    WHERE v.variant_id = 3
      AND jh.end_date >= ADD_MONTHS(TRUNC(SYSDATE), -v.recent_job_history_months)
),
managers AS (
    SELECT DISTINCT manager_id AS employee_id FROM t1_departments WHERE manager_id IS NOT NULL
),
variante AS (
    SELECT excluded_department_id, min_years_service, gap_high_threshold_pct,
           gap_mid_threshold_pct, raise_high_pct, raise_mid_pct, raise_low_pct,
           max_salary_vs_avg_pct
    FROM t1_variants WHERE variant_id = 3
),
elegibles AS (
    SELECT e.salary AS salary_before,
        CASE
            WHEN ROUND((ds.dept_avg_salary - e.salary) / ds.dept_avg_salary * 100, 2) > v.gap_high_threshold_pct
                THEN ROUND(e.salary * (1 + v.raise_high_pct / 100), 2)
            WHEN ROUND((ds.dept_avg_salary - e.salary) / ds.dept_avg_salary * 100, 2) > v.gap_mid_threshold_pct
                THEN ROUND(e.salary * (1 + v.raise_mid_pct / 100), 2)
            ELSE ROUND(e.salary * (1 + v.raise_low_pct / 100), 2)
        END AS salary_after
    FROM t1_employees e
    JOIN dept_stats ds ON e.department_id = ds.department_id
    CROSS JOIN variante v
    LEFT JOIN recent_history rh ON e.employee_id = rh.employee_id
    LEFT JOIN managers m ON e.employee_id = m.employee_id
    WHERE e.department_id IS NOT NULL
      AND e.department_id <> v.excluded_department_id
      AND ds.dept_employee_count >= 3
      AND ROUND(MONTHS_BETWEEN(SYSDATE, e.hire_date) / 12, 1) >= v.min_years_service
      AND rh.employee_id IS NULL AND m.employee_id IS NULL
      AND ds.dept_avg_salary > e.salary
)
SELECT
    COUNT(*)                               AS total_eligible_employees,
    SUM(salary_before)                     AS total_salary_before,
    SUM(salary_after)                      AS total_salary_after,
    SUM(salary_after) - SUM(salary_before) AS total_increment
FROM elegibles;

-- 3.2 Detalle por empleado elegible
WITH dept_stats AS (
    SELECT department_id, AVG(salary) AS dept_avg_salary,
           COUNT(*) AS dept_employee_count
    FROM t1_employees WHERE department_id IS NOT NULL
    GROUP BY department_id
),
recent_history AS (
    SELECT DISTINCT jh.employee_id FROM t1_job_history jh, t1_variants v
    WHERE v.variant_id = 3
      AND jh.end_date >= ADD_MONTHS(TRUNC(SYSDATE), -v.recent_job_history_months)
),
managers AS (
    SELECT DISTINCT manager_id AS employee_id FROM t1_departments WHERE manager_id IS NOT NULL
),
variante AS (
    SELECT excluded_department_id, min_years_service, gap_high_threshold_pct,
           gap_mid_threshold_pct, raise_high_pct, raise_mid_pct, raise_low_pct
    FROM t1_variants WHERE variant_id = 3
)
SELECT
    e.employee_id,
    e.department_id,
    e.salary AS salary_before,
    CASE
        WHEN ROUND((ds.dept_avg_salary - e.salary) / ds.dept_avg_salary * 100, 2) > v.gap_high_threshold_pct
            THEN ROUND(e.salary * (1 + v.raise_high_pct / 100), 2)
        WHEN ROUND((ds.dept_avg_salary - e.salary) / ds.dept_avg_salary * 100, 2) > v.gap_mid_threshold_pct
            THEN ROUND(e.salary * (1 + v.raise_mid_pct / 100), 2)
        ELSE ROUND(e.salary * (1 + v.raise_low_pct / 100), 2)
    END AS salary_after,
    CASE
        WHEN ROUND((ds.dept_avg_salary - e.salary) / ds.dept_avg_salary * 100, 2) > v.gap_high_threshold_pct
            THEN v.raise_high_pct
        WHEN ROUND((ds.dept_avg_salary - e.salary) / ds.dept_avg_salary * 100, 2) > v.gap_mid_threshold_pct
            THEN v.raise_mid_pct
        ELSE v.raise_low_pct
    END AS adjustment_pct,
    CASE
        WHEN ROUND((ds.dept_avg_salary - e.salary) / ds.dept_avg_salary * 100, 2) > v.gap_high_threshold_pct
            THEN 'AJUSTE_ALTO'
        WHEN ROUND((ds.dept_avg_salary - e.salary) / ds.dept_avg_salary * 100, 2) > v.gap_mid_threshold_pct
            THEN 'AJUSTE_MEDIO'
        ELSE 'AJUSTE_BAJO'
    END AS rule_applied
FROM t1_employees e
JOIN dept_stats ds ON e.department_id = ds.department_id
CROSS JOIN variante v
LEFT JOIN recent_history rh ON e.employee_id = rh.employee_id
LEFT JOIN managers m ON e.employee_id = m.employee_id
WHERE e.department_id IS NOT NULL
  AND e.department_id <> v.excluded_department_id
  AND ds.dept_employee_count >= 3
  AND ROUND(MONTHS_BETWEEN(SYSDATE, e.hire_date) / 12, 1) >= v.min_years_service
  AND rh.employee_id IS NULL AND m.employee_id IS NULL
  AND ds.dept_avg_salary > e.salary
ORDER BY e.department_id, e.employee_id;

-- 3.3 Control de topes por departamento
WITH dept_stats AS (
    SELECT department_id, AVG(salary) AS dept_avg_salary,
           MAX(salary) AS dept_max_salary, COUNT(*) AS dept_employee_count
    FROM t1_employees WHERE department_id IS NOT NULL
    GROUP BY department_id
),
variante AS (
    SELECT max_salary_vs_avg_pct FROM t1_variants WHERE variant_id = 3
)
SELECT
    d.department_id,
    d.department_name,
    ds.dept_avg_salary,
    ds.dept_max_salary,
    ROUND(ds.dept_avg_salary * (1 + v.max_salary_vs_avg_pct / 100), 2) AS max_allowed_salary_by_variant
FROM dept_stats ds
JOIN t1_departments d ON ds.department_id = d.department_id
CROSS JOIN variante v
ORDER BY d.department_id;

--COMENTARIO OBLIGATORIO:
-- La prevalidacion calcula el impacto del ajuste salarial sin modificar ningun dato.
-- Primero se muestra un resumen global con el total de empleados impactados y la
-- diferencia en nomina antes y despues del ajuste. Luego se detalla el salario
-- proyectado de cada elegible con su regla aplicada. Finalmente se verifica que
-- ningun salario ajustado supere el tope maximo permitido por la variante 3,
-- que es el 118% del promedio del departamento. Si algun tope se incumple,
-- debe hacerse ROLLBACK en la siguiente etapa en lugar de COMMIT.


-- ============================================================
-- 4. EJECUCIÓN TRANSACCIONAL
-- OBJETIVO:
-- Ejecutar la actualización real y registrar la auditoría.
--
-- DEBE INCLUIR OBLIGATORIAMENTE:
-- 1. SAVEPOINT
-- 2. UPDATE o MERGE para actualizar salarios
-- 3. INSERT a AUDIT_SALARY_ADJUSTMENTS_T1
-- 4. Validación intermedia
-- 5. COMMIT o ROLLBACK TO SAVEPOINT
--
-- IMPORTANTE:
-- - La auditoría debe usar el valor &p_execution_tag
-- - La auditoría debe usar el valor &p_variant_id
-- - Debe usar la secuencia AUDIT_SALARY_ADJ_T1_SEQ.NEXTVAL
-- ============================================================

PROMPT ===== 4. EJECUCIÓN TRANSACCIONAL =====

SAVEPOINT sv_before_adjustment;

-- 4.1 ACTUALIZACIÓN DE SALARIOS
UPDATE t1_employees e
SET e.salary = (
    WITH dept_stats AS (
        SELECT department_id,
               AVG(salary) AS dept_avg_salary,
               COUNT(*)    AS dept_employee_count
        FROM t1_employees
        WHERE department_id IS NOT NULL
        GROUP BY department_id
    )
    SELECT
        CASE
            WHEN ROUND((ds.dept_avg_salary - e2.salary)
                 / ds.dept_avg_salary * 100, 2) > v.gap_high_threshold_pct
                THEN ROUND(e2.salary * (1 + v.raise_high_pct / 100), 2)
            WHEN ROUND((ds.dept_avg_salary - e2.salary)
                 / ds.dept_avg_salary * 100, 2) > v.gap_mid_threshold_pct
                THEN ROUND(e2.salary * (1 + v.raise_mid_pct / 100), 2)
            ELSE ROUND(e2.salary * (1 + v.raise_low_pct / 100), 2)
        END
    FROM t1_employees e2
    JOIN dept_stats ds ON e2.department_id = ds.department_id
    CROSS JOIN t1_variants v
    LEFT JOIN t1_job_history jh
           ON e2.employee_id = jh.employee_id
          AND jh.end_date >= ADD_MONTHS(TRUNC(SYSDATE), -v.recent_job_history_months)
    LEFT JOIN t1_departments mgr ON e2.employee_id = mgr.manager_id
    WHERE v.variant_id             = &p_variant_id
      AND e2.employee_id           = e.employee_id
      AND e2.department_id IS NOT NULL
      AND e2.department_id        <> v.excluded_department_id
      AND ds.dept_employee_count  >= 3
      AND ROUND(MONTHS_BETWEEN(SYSDATE, e2.hire_date) / 12, 1) >= v.min_years_service
      AND jh.employee_id IS NULL
      AND mgr.manager_id IS NULL
      AND ds.dept_avg_salary       > e2.salary
)
WHERE e.employee_id IN (
    SELECT e2.employee_id
    FROM t1_employees e2
    JOIN (
        SELECT department_id,
               AVG(salary) AS dept_avg_salary,
               COUNT(*)    AS dept_employee_count
        FROM t1_employees
        WHERE department_id IS NOT NULL
        GROUP BY department_id
    ) ds ON e2.department_id = ds.department_id
    CROSS JOIN t1_variants v
    LEFT JOIN t1_job_history jh
           ON e2.employee_id = jh.employee_id
          AND jh.end_date >= ADD_MONTHS(TRUNC(SYSDATE), -v.recent_job_history_months)
    LEFT JOIN t1_departments mgr ON e2.employee_id = mgr.manager_id
    WHERE v.variant_id             = &p_variant_id
      AND e2.department_id IS NOT NULL
      AND e2.department_id        <> v.excluded_department_id
      AND ds.dept_employee_count  >= 3
      AND ROUND(MONTHS_BETWEEN(SYSDATE, e2.hire_date) / 12, 1) >= v.min_years_service
      AND jh.employee_id IS NULL
      AND mgr.manager_id IS NULL
      AND ds.dept_avg_salary       > e2.salary
);


-- 4.2 INSERCIÓN EN AUDITORÍA
INSERT INTO audit_salary_adjustments_t1 (
    audit_id, execution_tag, variant_id, employee_id, department_id,
    salary_before, salary_after, pct_gap_to_avg_before,
    rule_applied, executed_by, executed_at, notes
)
SELECT
    AUDIT_SALARY_ADJ_T1_SEQ.NEXTVAL,
    'P01_FINAL',
    3,
    a.employee_id,
    a.department_id,
    a.salary_before,
    e.salary,
    a.pct_gap,
    a.rule_applied,
    USER,
    SYSDATE,
    'Ajuste salarial variante 3 - Ajuste conservador'
FROM t1_employees e
JOIN (
    WITH dept_stats AS (
        SELECT department_id,
               AVG(salary) AS dept_avg_salary,
               COUNT(*)    AS dept_employee_count
        FROM t1_employees
        WHERE department_id IS NOT NULL
        GROUP BY department_id
    ),
    var_params AS (
        SELECT excluded_department_id, min_years_service, gap_high_threshold_pct,
               gap_mid_threshold_pct, raise_high_pct, raise_mid_pct, raise_low_pct,
               recent_job_history_months
        FROM t1_variants WHERE variant_id = 3
    )
    SELECT DISTINCT
        e2.employee_id,
        e2.department_id,
        CASE
            WHEN ROUND((ds.dept_avg_salary - e2.salary)
                 / ds.dept_avg_salary * 100, 2) > vp.gap_high_threshold_pct
                THEN ROUND(e2.salary / (1 + vp.raise_high_pct / 100), 2)
            WHEN ROUND((ds.dept_avg_salary - e2.salary)
                 / ds.dept_avg_salary * 100, 2) > vp.gap_mid_threshold_pct
                THEN ROUND(e2.salary / (1 + vp.raise_mid_pct / 100), 2)
            ELSE ROUND(e2.salary / (1 + vp.raise_low_pct / 100), 2)
        END AS salary_before,
        ROUND((ds.dept_avg_salary - e2.salary)
              / ds.dept_avg_salary * 100, 2) AS pct_gap,
        CASE
            WHEN ROUND((ds.dept_avg_salary - e2.salary)
                 / ds.dept_avg_salary * 100, 2) > vp.gap_high_threshold_pct
                THEN 'AJUSTE_ALTO'
            WHEN ROUND((ds.dept_avg_salary - e2.salary)
                 / ds.dept_avg_salary * 100, 2) > vp.gap_mid_threshold_pct
                THEN 'AJUSTE_MEDIO'
            ELSE 'AJUSTE_BAJO'
        END AS rule_applied
    FROM t1_employees e2
    JOIN dept_stats ds ON e2.department_id = ds.department_id
    CROSS JOIN var_params vp
    LEFT JOIN t1_job_history jh
           ON e2.employee_id = jh.employee_id
          AND jh.end_date >= ADD_MONTHS(TRUNC(SYSDATE), -vp.recent_job_history_months)
    LEFT JOIN t1_departments mgr ON e2.employee_id = mgr.manager_id
    WHERE e2.department_id IS NOT NULL
      AND e2.department_id <> vp.excluded_department_id
      AND ds.dept_employee_count >= 3
      AND ROUND(MONTHS_BETWEEN(SYSDATE, e2.hire_date) / 12, 1) >= vp.min_years_service
      AND jh.employee_id IS NULL
      AND mgr.manager_id IS NULL
      AND ds.dept_avg_salary > e2.salary
) a ON e.employee_id = a.employee_id;



-- 4.3 VALIDACIÓN INTERMEDIA

-- Debe mostrar, como mínimo, estas columnas:
--   employee_id
--   department_id
--   current_salary
--   original_salary
--   allowed_max_salary
--   validation_status
--
-- validation_status debe indicar si cumple o no cumple.

PROMPT ===== 4.3 VALIDACIÓN INTERMEDIA =====
SELECT
    e.employee_id,
    e.department_id,
    e.salary                                                         AS current_salary,
    a.salary_before                                                  AS original_salary,
    ROUND(ds.dept_avg_salary * (1 + v.max_salary_vs_avg_pct / 100), 2) AS allowed_max_salary,
    CASE
        WHEN e.salary <= ROUND(ds.dept_avg_salary
             * (1 + v.max_salary_vs_avg_pct / 100), 2) THEN 'OK'
        ELSE 'EXCEDE_TOPE'
    END                                                              AS validation_status
FROM t1_employees e
JOIN audit_salary_adjustments_t1 a
    ON e.employee_id = a.employee_id
   AND a.execution_tag = 'P01_FINAL'
JOIN (
    SELECT department_id, AVG(salary) AS dept_avg_salary
    FROM t1_employees
    WHERE department_id IS NOT NULL
    GROUP BY department_id
) ds ON e.department_id = ds.department_id
CROSS JOIN (
    SELECT max_salary_vs_avg_pct
    FROM t1_variants WHERE variant_id = 3
) v;


-- 4.4 CONTROL TRANSACCIONAL
-- Debe demostrar UNO de estos escenarios:
-- A. COMMIT si toda la validación es correcta
-- B. ROLLBACK TO SAVEPOINT si detecta incumplimientos
--
-- ESCRIBA AQUÍ SU DECISIÓN TRANSACCIONAL Y AGREGUE UN COMENTARIO
COMMIT;
-- Se realiza COMMIT porque la validacion intermedia confirmo que todos los salarios
-- ajustados estan dentro del tope permitido por la variante 3 (118% del promedio
-- del departamento). Ningún registro mostro EXCEDE_TOPE, por lo tanto la transaccion
-- es consistente y se confirman los cambios de forma permanente.

--COMENTARIO GENERAL:
-- La etapa 4 ejecuto el ajuste salarial de forma controlada siguiendo estos pasos:
-- Primero se establecio un SAVEPOINT como punto de restauracion antes de tocar datos.
-- Luego el UPDATE modifico el salario de 58 empleados elegibles segun las reglas
-- de la variante 3, calculando el nuevo salario con el porcentaje correspondiente
-- segun la brecha de cada empleado respecto al promedio de su departamento.
-- Despues se inserto un registro en la tabla de auditoria por cada empleado ajustado,
-- dejando evidencia del salario antes, el salario despues, la regla aplicada,
-- el usuario y la fecha de ejecucion bajo el tag P01_FINAL.
-- La validacion intermedia confirmo que ningun salario supero el tope permitido,
-- por lo que se procedio con COMMIT para confirmar los cambios de forma permanente.

-- ============================================================
-- 5. VALIDACIÓN POSTERIOR
-- OBJETIVO:
-- Demostrar el resultado final de la transacción.
--
-- DEBE MOSTRAR, COMO MÍNIMO, ESTAS 4 SALIDAS:
--
-- SALIDA 1. Empleados impactados
-- Columnas mínimas:
--   employee_id, first_name, last_name, department_id,
--   salary_before, salary_after, execution_tag
--
-- SALIDA 2. Resumen económico final
-- Columnas mínimas:
--   total_rows_audited, total_salary_before, total_salary_after, total_increment
--
-- SALIDA 3. Validación de topes
-- Columnas mínimas:
--   employee_id, department_id, salary_after, allowed_max_salary, top_limit_status
--
-- SALIDA 4. Auditoría generada
-- Columnas mínimas:
--   audit_id, execution_tag, variant_id, employee_id, department_id,
--   salary_before, salary_after, rule_applied, executed_by, executed_at
--
-- IMPORTANTE:
-- Todas las validaciones posteriores deben filtrar por &p_execution_tag
-- ============================================================

PROMPT ===== 5. VALIDACIÓN POSTERIOR =====

-- SALIDA 1: Empleados impactados
SELECT
    a.employee_id,
    e.first_name,
    e.last_name,
    a.department_id,
    a.salary_before,
    a.salary_after,
    a.execution_tag
FROM audit_salary_adjustments_t1 a
JOIN t1_employees e ON a.employee_id = e.employee_id
WHERE a.execution_tag = '&p_execution_tag'
ORDER BY a.department_id, a.employee_id;

-- SALIDA 2: Resumen economico final
SELECT
    COUNT(*)                             AS total_rows_audited,
    SUM(salary_before)                   AS total_salary_before,
    SUM(salary_after)                    AS total_salary_after,
    SUM(salary_after) - SUM(salary_before) AS total_increment
FROM audit_salary_adjustments_t1
WHERE execution_tag = '&p_execution_tag';

-- SALIDA 3: Validacion de topes
SELECT
    a.employee_id,
    a.department_id,
    a.salary_after,
    ROUND(ds.dept_avg_salary * (1 + v.max_salary_vs_avg_pct / 100), 2) AS allowed_max_salary,
    CASE
        WHEN a.salary_after <= ROUND(ds.dept_avg_salary
             * (1 + v.max_salary_vs_avg_pct / 100), 2) THEN 'DENTRO_DEL_TOPE'
        ELSE 'EXCEDE_TOPE'
    END AS top_limit_status
FROM audit_salary_adjustments_t1 a
JOIN (
    SELECT department_id, AVG(salary) AS dept_avg_salary
    FROM t1_employees
    WHERE department_id IS NOT NULL
    GROUP BY department_id
) ds ON a.department_id = ds.department_id
CROSS JOIN (
    SELECT max_salary_vs_avg_pct
    FROM t1_variants WHERE variant_id = &p_variant_id
) v
WHERE a.execution_tag = '&p_execution_tag'
ORDER BY a.department_id, a.employee_id;

-- SALIDA 4: Auditoria generada
SELECT
    audit_id,
    execution_tag,
    variant_id,
    employee_id,
    department_id,
    salary_before,
    salary_after,
    rule_applied,
    executed_by,
    executed_at
FROM audit_salary_adjustments_t1
WHERE execution_tag = '&p_execution_tag'
ORDER BY audit_id;

-- ============================================================
-- 6. JUSTIFICACIÓN TÉCNICA
-- Responder dentro del script, en comentarios.
-- Cada respuesta debe tener entre 3 y 6 líneas.
-- ============================================================

-- ATOMICIDAD:
-- Explique cómo su solución demuestra atomicidad.
--
-- RESPUESTA:
-- La transaccion agrupa el UPDATE y el INSERT en auditoria como una sola unidad.
-- Si cualquiera de los dos falla, el ROLLBACK TO SAVEPOINT deshace ambos por completo.
-- No existe un estado intermedio donde el salario este actualizado pero sin registro
-- en auditoria, o viceversa. Todo ocurre junto o no ocurre nada.

-- CONSISTENCIA:
-- Explique cómo su solución asegura que los datos quedan válidos
-- después de la operación.
--
-- RESPUESTA:
-- Antes del COMMIT se ejecuto una validacion intermedia que verifico que ningun
-- salario ajustado superara el tope del 118% del promedio del departamento.
-- Ademas los filtros del UPDATE garantizan que solo empleados elegibles fueron
-- modificados. El COMMIT solo se ejecuto al confirmar que todos los registros
-- mostraron OK en la validacion, dejando la base en un estado valido y consistente.

-- AISLAMIENTO:
-- Explique cómo se comportaría su transacción frente a otras sesiones.
--
-- RESPUESTA:
-- Mientras la transaccion no tenia COMMIT, los cambios en T1_EMPLOYEES solo eran
-- visibles para la sesion actual. Cualquier otra sesion que consultara los salarios
-- veria los valores originales hasta que se confirmara el COMMIT. Esto evita que
-- otro usuario lea datos a medio actualizar durante la ejecucion de la transaccion.

-- DURABILIDAD:
-- Explique qué garantiza la persistencia del cambio una vez confirmado.
--
-- RESPUESTA:
-- Una vez ejecutado el COMMIT, Oracle escribe los cambios en el redo log y los
-- hace permanentes en disco. Incluso si el sistema falla justo despues del COMMIT,
-- Oracle puede recuperar los cambios al reiniciarse usando ese registro. Los datos
-- no dependen de que la sesion siga abierta para persistir.

-- USO DE SAVEPOINT / ROLLBACK:
-- Explique qué riesgo controló y por qué ese punto de restauración
-- era necesario.
--
-- RESPUESTA:
-- El SAVEPOINT controlo el riesgo de dejar los datos en un estado inconsistente
-- si la validacion intermedia detectaba salarios que superaran el tope permitido.
-- Sin el SAVEPOINT un error obligaria a hacer ROLLBACK total perdiendo cualquier
-- trabajo previo de la sesion. Con el SAVEPOINT se puede deshacer unicamente
-- el ajuste salarial y corregir sin afectar nada mas.

PROMPT ===== Fin de plantilla =====
